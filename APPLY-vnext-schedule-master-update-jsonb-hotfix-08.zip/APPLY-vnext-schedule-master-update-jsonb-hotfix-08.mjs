import fs from "node:fs";
import { execSync } from "node:child_process";

const branch = execSync("git branch --show-current", { encoding: "utf8" }).trim();
if (branch !== "vNext") throw new Error(`Expected vNext branch, got ${branch}`);

const file = "tests/integration/schedule-master-foundation.test.ts";
if (!fs.existsSync(file)) throw new Error(`${file} is missing.`);

let source = fs.readFileSync(file, "utf8");

const oldChanged = 'const changed=JSON.stringify([{taskId:ids.taskB,sequence:1,plannedDurationMinutes:25,evidenceRule:"NONE",randomEveryN:null,randomEvidenceType:null},{taskId:ids.taskA,sequence:2,plannedDurationMinutes:10,evidenceRule:"VIDEO",randomEveryN:null,randomEvidenceType:null}]);';
const newChanged = 'const changed=[{taskId:ids.taskB,sequence:1,plannedDurationMinutes:25,evidenceRule:"NONE",randomEveryN:null,randomEvidenceType:null},{taskId:ids.taskA,sequence:2,plannedDurationMinutes:10,evidenceRule:"VIDEO",randomEveryN:null,randomEvidenceType:null}];';

if (source.includes(newChanged)) {
  console.log("Changed Task payload is already an array.");
} else {
  if (!source.includes(oldChanged)) throw new Error("Expected changed Task payload anchor not found.");
  source = source.replace(oldChanged, newChanged);
  console.log("Converted changed Schedule Task payload from JSON string to JS array.");
}

const oldBinding = '${changed}::jsonb';
const newBinding = '${tx.json(changed)}';

if (source.includes(newBinding)) {
  console.log("Update Schedule Task payload already uses tx.json().");
} else {
  if (!source.includes(oldBinding)) throw new Error("Expected update JSONB binding anchor not found.");
  source = source.replace(oldBinding, newBinding);
  console.log("Updated Schedule Task payload binding to tx.json(changed).");
}

fs.writeFileSync(file, source, "utf8");

execSync("npx eslint tests/integration/schedule-master-foundation.test.ts", { stdio: "inherit" });
execSync("npm run typecheck", { stdio: "inherit" });
execSync("git --no-pager diff --check", { stdio: "inherit" });

console.log("Schedule update JSONB hotfix passed ESLint, full typecheck, and diff check.");
console.log("Next: rerun focused Schedule tests. Do NOT reapply migration 0008.");
