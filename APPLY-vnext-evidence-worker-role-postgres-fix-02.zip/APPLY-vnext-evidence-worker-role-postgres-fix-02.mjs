import fs from "node:fs";
import {execSync} from "node:child_process";

const branch=execSync("git branch --show-current",{encoding:"utf8"}).trim();
if(branch!=="vNext")throw new Error(`Expected vNext branch, got ${branch}`);

const baseline="856382812aac28b58df2eea0fad7f82d58f912d2";
const head=execSync("git rev-parse HEAD",{encoding:"utf8"}).trim();
try{execSync(`git merge-base --is-ancestor ${baseline} ${head}`,{stdio:"ignore"});}
catch{throw new Error(`Current HEAD ${head} does not descend from validated Foundation 02 checkpoint ${baseline}`);}

const file="supabase-privileged/002_evidence_worker_capability_role.sql";
fs.mkdirSync("supabase-privileged",{recursive:true});
fs.writeFileSync(file,'-- Supabase privileged setup: Evidence worker capability role 02\n--\n-- Run separately in the Supabase SQL Editor AFTER application migration 0018.\n-- Do NOT run with vnext_migrator: it intentionally has no CREATEROLE.\n--\n-- Supabase SQL Editor commonly runs as project role "postgres", which has\n-- CREATEROLE but is intentionally not SUPERUSER. PostgreSQL does not allow a\n-- non-superuser to execute ALTER ROLE clauses that touch SUPERUSER/BYPASSRLS\n-- attributes, even when setting them to the safe "NO..." state.\n--\n-- Therefore:\n--   1. create the capability role with PostgreSQL\'s safe defaults plus NOLOGIN;\n--   2. do NOT ALTER restricted role attributes;\n--   3. verify the resulting attributes explicitly after creation;\n--   4. fail closed if any unsafe attribute is present.\n--\n-- CREATE ROLE defaults are NOSUPERUSER, NOCREATEDB, NOCREATEROLE,\n-- NOREPLICATION, NOBYPASSRLS and NOLOGIN unless explicitly changed.\n\ndo $setup$\ndeclare\n  r record;\nbegin\n  if not exists(select 1 from pg_roles where rolname=\'vnext_evidence_worker\') then\n    execute \'create role vnext_evidence_worker nologin\';\n  end if;\n\n  select rolsuper,rolcreatedb,rolcreaterole,rolreplication,rolbypassrls,rolcanlogin\n    into r\n  from pg_roles\n  where rolname=\'vnext_evidence_worker\';\n\n  if r.rolsuper\n     or r.rolcreatedb\n     or r.rolcreaterole\n     or r.rolreplication\n     or r.rolbypassrls\n     or r.rolcanlogin then\n    raise exception \'vnext_evidence_worker has unsafe role attributes; privileged administrator intervention is required\';\n  end if;\n\n  execute \'revoke all on all tables in schema public from vnext_evidence_worker\';\n  execute \'revoke all on all sequences in schema public from vnext_evidence_worker\';\n  execute \'revoke all on schema public from vnext_evidence_worker\';\n\n  execute \'grant usage on schema app_private to vnext_evidence_worker\';\n\n  execute \'grant execute on function app_private.claim_evidence_worker_event(text,integer)\n    to vnext_evidence_worker\';\n  execute \'grant execute on function app_private.complete_evidence_worker_event(uuid,uuid,text)\n    to vnext_evidence_worker\';\n  execute \'grant execute on function app_private.fail_evidence_worker_event(uuid,uuid,text,text,integer)\n    to vnext_evidence_worker\';\n  execute \'grant execute on function app_private.claim_evidence_processing(uuid,bigint,text,text)\n    to vnext_evidence_worker\';\n  execute \'grant execute on function app_private.complete_evidence_processing(\n    uuid,bigint,uuid,text,text,text,bigint,text,text,text,bigint,text,boolean,text,text\n  ) to vnext_evidence_worker\';\n  execute \'grant execute on function app_private.mark_evidence_original_deleted(uuid,bigint,text,text,text)\n    to vnext_evidence_worker\';\n\n  execute \'revoke execute on function app_private.authorize_occurrence_evidence_read(uuid,text)\n    from vnext_evidence_worker\';\n  execute \'revoke execute on function app_private.audit_evidence_read_url_issued(uuid,text,text,text)\n    from vnext_evidence_worker\';\nend\n$setup$;\n\n-- Verification output: all six role-attribute booleans must be false.\nselect\n  rolname,\n  rolsuper,\n  rolcreatedb,\n  rolcreaterole,\n  rolreplication,\n  rolbypassrls,\n  rolcanlogin\nfrom pg_roles\nwhere rolname=\'vnext_evidence_worker\';\n',"utf8");
console.log(`Replaced ${file} with Supabase project-postgres-compatible role setup.`);

for(const artifact of fs.readdirSync(".")){
 if(/^APPLY-vnext-evidence-worker-role-postgres-fix-02\.(?:zip|mjs)$/i.test(artifact)){
  fs.unlinkSync(artifact);
  console.log(`Removed temporary artifact: ${artifact}`);
 }
}

execSync("git --no-pager diff --check",{stdio:"inherit"});
console.log("Worker capability-role setup corrected for non-superuser SQL Editor execution.");
console.log("Migration 0018 is already applied. Do NOT rerun it.");
