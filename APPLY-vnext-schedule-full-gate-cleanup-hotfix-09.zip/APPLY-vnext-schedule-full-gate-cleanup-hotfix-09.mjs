import fs from "node:fs";
import { execSync } from "node:child_process";

const branch = execSync("git branch --show-current", { encoding: "utf8" }).trim();
if (branch !== "vNext") throw new Error(`Expected vNext branch, got ${branch}`);

const contractFile = "tests/module/work-area-qr-hardening-contract.test.ts";
const e2eFile = "e2e/work-area-qr-demo.spec.ts";
for (const file of [contractFile, e2eFile]) {
  if (!fs.existsSync(file)) throw new Error(`${file} is missing.`);
}

// 1) Keep the historical QR hardening continuity-numbering contract aligned
// with the Task Master section inserted into the current vNext context.
let contract = fs.readFileSync(contractFile, "utf8");
const replacements = [
  ['"## 10. Billing & Entitlements Foundation"', '"## 11. Billing & Entitlements Foundation"'],
  ['"## 11. Audit"', '"## 12. Audit"'],
  ['"## 22. Baseline Commit Chain"', '"## 23. Baseline Commit Chain"'],
  ['"## 21. Baseline Commit Chain"', '"## 22. Baseline Commit Chain"'],
];

let contractFixes = 0;
for (const [from, to] of replacements) {
  if (contract.includes(from)) {
    contract = contract.replaceAll(from, to);
    contractFixes += 1;
  }
}
if (!contract.includes('"## 11. Billing & Entitlements Foundation"') ||
    !contract.includes('"## 12. Audit"') ||
    !contract.includes('"## 23. Baseline Commit Chain"')) {
  throw new Error("Could not establish current continuity numbering assertions.");
}
fs.writeFileSync(contractFile, contract, "utf8");
console.log(`Continuity numbering contract updated (${contractFixes} anchor group(s)).`);

// 2) Resolve Playwright strict-mode ambiguity by asking for the unique Task heading.
let e2e = fs.readFileSync(e2eFile, "utf8");
const oldLocator = 'page.getByText("Clean main entrance glass")';
const newLocator = 'page.getByRole("heading",{name:"Clean main entrance glass"})';
if (e2e.includes(newLocator)) {
  console.log("Demo Task heading locator is already strict-mode safe.");
} else {
  if (!e2e.includes(oldLocator)) throw new Error("Expected Demo Task locator anchor not found.");
  e2e = e2e.replace(oldLocator, newLocator);
  fs.writeFileSync(e2eFile, e2e, "utf8");
  console.log("Demo Task locator changed to unique heading role.");
}

// 3) next-env.d.ts was touched by the Next build only; restore generated tracked file.
try {
  execSync("git restore --source=HEAD -- next-env.d.ts", { stdio: "inherit" });
  console.log("Restored generated next-env.d.ts to tracked baseline.");
} catch {
  console.log("next-env.d.ts restore skipped.");
}

execSync(`npx eslint "${contractFile}" "${e2eFile}"`, { stdio: "inherit" });
execSync(`npx vitest run "${contractFile}"`, { stdio: "inherit" });
execSync("npm run typecheck", { stdio: "inherit" });
execSync("npm run test:e2e", { stdio: "inherit" });
execSync("git --no-pager diff --check", { stdio: "inherit" });

console.log("Full-gate cleanup hotfix passed contract test, typecheck, E2E, and diff check.");
console.log("Next: rerun npm run test, then git status --short. Do not commit yet.");
