import fs from "node:fs";
import { execSync } from "node:child_process";

const branch = execSync("git branch --show-current", { encoding: "utf8" }).trim();
if (branch !== "vNext") throw new Error(`Expected vNext branch, got ${branch}`);

const actionsFile = "src/lib/schedules/actions.ts";
const testFile = "tests/integration/schedule-master-foundation.test.ts";
for (const file of [actionsFile, testFile]) {
  if (!fs.existsSync(file)) throw new Error(`${file} is missing.`);
}

// TypeScript only: use non-null assertions at the SQL interpolation points.
// The runtime guard already rejects missing scheduleId/expectedVersion before this query.
let actions = fs.readFileSync(actionsFile, "utf8");
const fnStart = actions.indexOf("export async function updateSchedule");
const fnEnd = actions.indexOf("export async function toggleScheduleStatus", fnStart);
if (fnStart < 0 || fnEnd < 0) throw new Error("Could not isolate updateSchedule().");

const prefix = actions.slice(0, fnStart);
let fn = actions.slice(fnStart, fnEnd);
const suffix = actions.slice(fnEnd);

let idFix = 0;
let versionFix = 0;

if (!fn.includes("${input.scheduleId!}")) {
  fn = fn.replace(/\$\{input\.scheduleId\}/g, () => {
    idFix += 1;
    return "${input.scheduleId!}";
  });
}
if (!fn.includes("${input.expectedVersion!}")) {
  fn = fn.replace(/\$\{input\.expectedVersion\}/g, () => {
    versionFix += 1;
    return "${input.expectedVersion!}";
  });
}

if (!fn.includes("${input.scheduleId!}") || !fn.includes("${input.expectedVersion!}")) {
  throw new Error("Could not establish non-null Schedule SQL arguments.");
}

fs.writeFileSync(actionsFile, prefix + fn + suffix, "utf8");
console.log(`Schedule SQL non-null assertions applied: scheduleId=${idFix}, expectedVersion=${versionFix}.`);

// Deterministic test fixture lookups were created immediately above the lookups.
// Assert those finds for TypeScript without changing runtime behavior.
let test = fs.readFileSync(testFile, "utf8");
const fixes = [
  [/areas\.find\((x=>x\.site_id===ids\.siteA)\)(?!\!)\.id/g, "areas.find($1)!.id"],
  [/areas\.find\((x=>x\.site_id===ids\.siteB)\)(?!\!)\.id/g, "areas.find($1)!.id"],
  [/tasks\.find\((x=>x\.name==="Clean entrance glass")\)(?!\!)\.id/g, "tasks.find($1)!.id"],
  [/tasks\.find\((x=>x\.name==="Restock lobby supplies")\)(?!\!)\.id/g, "tasks.find($1)!.id"],
];

let fixtureFixes = 0;
for (const [pattern, replacement] of fixes) {
  const before = test;
  test = test.replace(pattern, replacement);
  if (test !== before) fixtureFixes += 1;
}

const requiredAssertions = [
  "areas.find(x=>x.site_id===ids.siteA)!.id",
  "areas.find(x=>x.site_id===ids.siteB)!.id",
  'tasks.find(x=>x.name==="Clean entrance glass")!.id',
  'tasks.find(x=>x.name==="Restock lobby supplies")!.id',
];
for (const marker of requiredAssertions) {
  if (!test.includes(marker)) throw new Error(`Fixture assertion marker missing: ${marker}`);
}
fs.writeFileSync(testFile, test, "utf8");
console.log(`Fixture non-null assertions applied: ${fixtureFixes}.`);

execSync(
  "npx eslint src/lib/schedules/model.ts src/lib/schedules/server.ts src/lib/schedules/actions.ts src/app/workspace/schedules/page.tsx src/app/workspace/page.tsx src/app/demo/page.tsx tests/integration/schedule-master-foundation.test.ts tests/module/schedule-master-contract.test.ts tests/unit/schedule-intent.test.ts e2e/work-area-qr-demo.spec.ts scripts/db-apply-schedule-master-08.mjs",
  { stdio: "inherit" }
);
execSync("npm run typecheck", { stdio: "inherit" });
execSync("git --no-pager diff --check", { stdio: "inherit" });

console.log("Schedule Master TypeScript hotfix 05 passed focused ESLint, full typecheck, and diff check.");
console.log("Do not run the database migration until this output is reviewed.");
