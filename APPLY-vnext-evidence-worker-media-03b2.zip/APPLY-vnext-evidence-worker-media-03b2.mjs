import fs from "node:fs";
import path from "node:path";
import {execSync} from "node:child_process";

const BASELINE="93aae8e53f4b0f9bcb11358bbc430f257adcb9b3";
const PAYLOAD=".apply-03b2";
const ARTIFACT_ZIP="APPLY-vnext-evidence-worker-media-03b2.zip";
const ARTIFACT_MJS="APPLY-vnext-evidence-worker-media-03b2.mjs";

function sh(cmd,opts={}){
  return execSync(cmd,{encoding:"utf8",stdio:opts.stdio??["ignore","pipe","pipe"]}).trim();
}
function assertHash(file,expected){
  if(!fs.existsSync(file))throw new Error(`Required file missing: ${file}`);
  const actual=sh(`git hash-object -- ${JSON.stringify(file)}`);
  if(actual!==expected)throw new Error(`${file} changed from the inspected vNext source (${actual} != ${expected}). Refusing unsafe patch.`);
}
function copyPayload(sourceName,target){
  const source=path.join(PAYLOAD,sourceName);
  if(!fs.existsSync(source))throw new Error(`Payload missing: ${sourceName}`);
  fs.mkdirSync(path.dirname(target),{recursive:true});
  fs.copyFileSync(source,target);
  console.log(`Wrote ${target}`);
}
function replaceOnce(source,oldText,newText,label){
  const count=source.split(oldText).length-1;
  if(count!==1)throw new Error(`${label}: expected anchor once, found ${count}. Refusing unsafe patch.`);
  return source.replace(oldText,newText);
}

const branch=sh("git branch --show-current");
if(branch!=="vNext")throw new Error(`Expected vNext branch, got ${branch}`);
try{
  execSync(`git merge-base --is-ancestor ${BASELINE} HEAD`,{stdio:"ignore"});
}catch{
  throw new Error(`Current HEAD must descend from validated 03B1 continuity checkpoint ${BASELINE}.`);
}

const trackedDirty=sh("git status --porcelain --untracked-files=no");
if(trackedDirty)throw new Error(`Tracked working tree must be clean before 03B2 install:\n${trackedDirty}`);

const hashes={
  ".env.example":"8428c9ff1a2ecdcbd0c1835a5575cae385e4ceb2",
  "package.json":"fb6d6561193217bdbbd4aea1813cb412409a81c8",
  "scripts/db-apply-evidence-worker-capability-grants.mjs":"503b22d6da95bfe9eae4735351b8e6949e6a1c5e",
  "worker/lib/evidence-transport.mjs":"3a8b7e94208f11f291d63f2fb7a940b7496153a7",
  "worker/evidence-worker.mjs":"7c45373bb73e8ca39474e3426308c84fdd842fb1",
  "worker/README.md":"155af248c389736acfa2ce5d113741548c927a66",
  "worker/Dockerfile.transport":"2592ec1ca8720b415f42bc31c64b7e483f3dd04a",
  "src/app/demo/page.tsx":"14574b5ae567b21961bc2083120b0b549cf2b818",
  "e2e/work-area-qr-demo.spec.ts":"560a5c75d7dd4540638a1440bc2dd69bd167ecbd",
  "tests/module/evidence-worker-transport-foundation-contract.test.ts":"3208a9dcb319f7153e7996f3098d22326dd5244f"
};
for(const [file,hash] of Object.entries(hashes))assertHash(file,hash);

for(const [source,target] of [
  ["0020.sql","drizzle/0020_evidence_worker_media_execution_hardening.sql"],
  ["db-apply-20.mjs","scripts/db-apply-evidence-worker-media-20.mjs"],
  ["grant.mjs","scripts/db-apply-evidence-worker-capability-grants.mjs"],
  ["evidence-media.mjs","worker/lib/evidence-media.mjs"],
  ["evidence-transport.mjs","worker/lib/evidence-transport.mjs"],
  ["worker-loop.mjs","worker/lib/evidence-worker-loop.mjs"],
  ["evidence-worker.mjs","worker/evidence-worker.mjs"],
  ["Dockerfile","worker/Dockerfile"],
  ["Dockerfile.transport","worker/Dockerfile.transport"],
  ["README.md","worker/README.md"],
  ["media-utils.test.mjs","tests/unit/evidence-worker-media-utils.test.mjs"],
  ["media-contract.test.ts","tests/module/evidence-worker-media-processing-contract.test.ts"],
  ["media-integration.test.ts","tests/integration/evidence-worker-media-execution-hardening.test.ts"],
  ["transport-contract.test.ts","tests/module/evidence-worker-transport-foundation-contract.test.ts"]
])copyPayload(source,target);

const pkg=JSON.parse(fs.readFileSync("package.json","utf8"));
pkg.scripts["db:evidence-worker-media:apply"]="node scripts/db-apply-evidence-worker-media-20.mjs";
pkg.scripts["worker:evidence:media-check"]="node worker/evidence-worker.mjs --media-check";
pkg.scripts["worker:evidence:once"]="node worker/evidence-worker.mjs --once";
pkg.scripts["worker:evidence:run"]="node worker/evidence-worker.mjs --run";
fs.writeFileSync("package.json",JSON.stringify(pkg,null,2)+"\n","utf8");

let env=fs.readFileSync(".env.example","utf8");
if(!env.includes("EVIDENCE_WORKER_POLL_INTERVAL_MS=")){
  env += `
# Evidence worker runtime tuning (optional; code defaults shown)
EVIDENCE_WORKER_POLL_INTERVAL_MS=3000
EVIDENCE_WORKER_EVENT_LEASE_SECONDS=120
EVIDENCE_WORKER_PROCESSING_LEASE_SECONDS=300
EVIDENCE_WORKER_HEARTBEAT_INTERVAL_MS=30000
EVIDENCE_WORKER_MAX_ATTEMPTS=5
`;
  fs.writeFileSync(".env.example",env,"utf8");
}

let demo=fs.readFileSync("src/app/demo/page.tsx","utf8");
if(!demo.includes("EVIDENCE MEDIA PROCESSING 03B2 DEMO")){
  const marker='\n<div className="demoBanner">';
  if(demo.split(marker).length-1!==1)throw new Error("Demo banner anchor was not unique.");
  const section=`
 <section className="demoOperations"><span className="eyebrow">EVIDENCE MEDIA PROCESSING 03B2 DEMO</span><h2>Real codecs, crash-safe retries, terminal-state queue acknowledgement</h2><div className="demoBehaviorGrid"><article><strong>Event-bound retry</strong><span>A processing claim is bound to the live outbox event token and current Evidence version, so a crash cannot strand the next delivery on a stale version snapshot.</span></article><article><strong>Independent observation</strong><span>The worker downloads the exact private original, computes SHA-256 from the bytes, magic-sniffs MIME, and validates image/video structure before trusting upload metadata.</span></article><article><strong>PHOTO normalization</strong><span>Sharp/libvips auto-orients and re-encodes photos to server-owned WebP normalized and preview derivatives, removing dependence on the original camera encoding.</span></article><article><strong>VIDEO normalization</strong><span>ffprobe validates the stream and FFmpeg creates H.264/AAC MP4 with fast-start plus a JPEG poster/preview at the exact server-owned paths.</span></article><article><strong>Retry + cleanup</strong><span>Bounded heartbeats keep long work alive; transient failures use exponential backoff, expire only the operational processing lease, and clean partial derivatives best-effort for safe overwrite on retry.</span></article><article><strong>Terminal-state acknowledgement</strong><span>Processing events can be acknowledged only after Evidence is VERIFIED or REJECTED; original-delete events only after the original is marked DELETED.</span></article><article><strong>Original disposal</strong><span>Successful normalization queues exact original deletion. REJECTED/failed source validation retains the original and never satisfies the Task evidence gate.</span></article><article><strong>Read-only Demo</strong><span>This section is synthetic: it performs no real queue claims, Storage reads/writes/deletes, media transcoding, or tenant mutations.</span></article></div></section>`;
  demo=demo.replace(marker,section+marker);
  fs.writeFileSync("src/app/demo/page.tsx",demo,"utf8");
}

let e2e=fs.readFileSync("e2e/work-area-qr-demo.spec.ts","utf8");
if(!e2e.includes("EVIDENCE MEDIA PROCESSING 03B2 DEMO")){
  const marker=' await expect(page.getByText(/No service-role key, JWT signing secret, or S3 static credential/i)).toBeVisible();\n';
  const addition=`${marker} await expect(page.getByText("EVIDENCE MEDIA PROCESSING 03B2 DEMO")).toBeVisible();
 await expect(page.getByText(/processing claim is bound to the live outbox event token and current Evidence version/i)).toBeVisible();
 await expect(page.getByText(/Sharp\\/libvips auto-orients/i)).toBeVisible();
 await expect(page.getByText(/FFmpeg creates H\\.264\\/AAC MP4/i)).toBeVisible();
 await expect(page.getByText(/acknowledged only after Evidence is VERIFIED or REJECTED/i)).toBeVisible();
`;
  e2e=replaceOnce(e2e,marker,addition,"Demo E2E 03B1 tail");
  fs.writeFileSync("e2e/work-area-qr-demo.spec.ts",e2e,"utf8");
}

console.log("Installing pinned Sharp 0.35.4 and updating package-lock.json...");
execSync("npm install --save-exact sharp@0.35.4",{stdio:"inherit"});

fs.rmSync(PAYLOAD,{recursive:true,force:true});
for(const artifact of [ARTIFACT_ZIP,ARTIFACT_MJS]){
  if(fs.existsSync(artifact)){
    fs.unlinkSync(artifact);
    console.log(`Removed temporary artifact: ${artifact}`);
  }
}

for(const file of [
  "scripts/db-apply-evidence-worker-media-20.mjs",
  "scripts/db-apply-evidence-worker-capability-grants.mjs",
  "worker/evidence-worker.mjs",
  "worker/lib/evidence-transport.mjs",
  "worker/lib/evidence-media.mjs",
  "worker/lib/evidence-worker-loop.mjs"
]){
  execSync(`node --check ${JSON.stringify(file)}`,{stdio:"inherit"});
}

execSync("npx vitest run tests/unit/evidence-worker-media-utils.test.mjs tests/module/evidence-worker-media-processing-contract.test.ts tests/module/evidence-worker-transport-foundation-contract.test.ts",{stdio:"inherit"});
execSync("npm run typecheck",{stdio:"inherit"});
execSync("npm run lint",{stdio:"inherit"});

execSync("git --no-pager diff --check",{stdio:"inherit"});

console.log("Evidence Worker Real Media Processing Foundation 03B2 source installed.");
console.log("Migration 0020 is NOT applied yet.");
console.log("The updated worker-role grants are NOT applied yet.");
console.log("No Storage policy, worker LOGIN, Auth machine principal, or credential was changed.");
console.log("Do not run worker:evidence:once or worker:evidence:run until migration 0020 and the worker-role re-grant are verified.");
