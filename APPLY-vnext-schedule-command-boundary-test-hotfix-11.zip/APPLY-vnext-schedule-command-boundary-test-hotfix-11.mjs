import fs from "node:fs";
import { execSync } from "node:child_process";

const branch=execSync("git branch --show-current",{encoding:"utf8"}).trim();
if(branch!=="vNext") throw new Error(`Expected vNext branch, got ${branch}`);

const file="tests/integration/schedule-master-foundation.test.ts";
if(!fs.existsSync(file)) throw new Error(`${file} is missing.`);

let source=fs.readFileSync(file,"utf8");

const desired = `await expect(asUser(tx=>tx\`update schedule_master set name='Forbidden' where id=\${ids.schedule} returning id\`)).rejects.toThrow(/permission denied/i);`;

if(source.includes(desired)){
  console.log("Schedule direct-DML regression is already updated.");
}else{
  const pattern = /const\s+write\s*=\s*await\s+asUser\(tx=>tx`update schedule_master set name='Forbidden' where id=\$\{ids\.schedule\} returning id`\)\s*;\s*expect\(write\)\.toHaveLength\(0\)\s*;/;
  if(!pattern.test(source)){
    const lines=source.split(/\r?\n/);
    const hit=lines.findIndex(line=>line.includes("update schedule_master set name='Forbidden'"));
    if(hit>=0){
      console.error("Found target line but it did not match expected structure:");
      console.error(`${hit+1}: ${lines[hit]}`);
    }
    throw new Error("Could not safely match the Schedule direct-update regression.");
  }
  source=source.replace(pattern, desired);
  fs.writeFileSync(file,source,"utf8");
  console.log("Updated Schedule regression to expect permission denial for direct runtime UPDATE.");
}

execSync(`npx eslint "${file}"`,{stdio:"inherit"});
execSync("npm run typecheck",{stdio:"inherit"});
execSync("git --no-pager diff --check",{stdio:"inherit"});
console.log("Schedule command-boundary regression hotfix 11 passed ESLint, typecheck, and diff check.");
console.log("Do NOT reapply migration 0009. Rerun the focused hardening tests.");
