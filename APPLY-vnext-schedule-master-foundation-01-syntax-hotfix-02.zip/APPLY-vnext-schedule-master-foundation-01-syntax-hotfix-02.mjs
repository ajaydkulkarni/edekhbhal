import fs from "node:fs";
import { execSync } from "node:child_process";

const branch = execSync("git branch --show-current", { encoding: "utf8" }).trim();
if (branch !== "vNext") throw new Error(`Expected vNext branch, got ${branch}`);

const file = "tests/integration/schedule-master-foundation.test.ts";
if (!fs.existsSync(file)) throw new Error(`${file} is missing. Run the Schedule Master installer first.`);

let source = fs.readFileSync(file, "utf8");
const lines = source.split("\n");
let fixes = 0;

for (let i = 0; i < lines.length; i += 1) {
  const line = lines[i];

  // Guarded repair for generated one-line asAdmin/asManager/asUser tagged-SQL assignments
  // where the call incorrectly ends with `; instead of `);
  if (
    /\bconst\s+\w+\s*=\s*await\s+as(?:Admin|Manager|User)\s*\(/.test(line) &&
    /`\s*;\s*$/.test(line) &&
    !/`\s*\)\s*;\s*$/.test(line)
  ) {
    lines[i] = line.replace(/`\s*;\s*$/, "`);");
    fixes += 1;
  }
}

if (fixes === 0) {
  console.log("No additional generated assignment syntax defects found.");
} else {
  source = lines.join("\n");
  fs.writeFileSync(file, source, "utf8");
  console.log(`Corrected ${fixes} additional Schedule integration-test call terminator(s).`);
}

execSync(
  "npx eslint src/lib/schedules/model.ts src/lib/schedules/server.ts src/lib/schedules/actions.ts src/app/workspace/schedules/page.tsx src/app/workspace/page.tsx src/app/demo/page.tsx tests/integration/schedule-master-foundation.test.ts tests/module/schedule-master-contract.test.ts tests/unit/schedule-intent.test.ts e2e/work-area-qr-demo.spec.ts scripts/db-apply-schedule-master-08.mjs",
  { stdio: "inherit" }
);
execSync("npm run typecheck", { stdio: "inherit" });
execSync("git --no-pager diff --check", { stdio: "inherit" });

console.log("Schedule Master syntax hardening hotfix applied; focused ESLint, typecheck, and diff check passed.");
console.log("Next: npm run db:schedule-master:apply");
