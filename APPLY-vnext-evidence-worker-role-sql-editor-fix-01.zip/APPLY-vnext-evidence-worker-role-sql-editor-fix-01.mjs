import fs from "node:fs";
import {execSync} from "node:child_process";

const branch=execSync("git branch --show-current",{encoding:"utf8"}).trim();
if(branch!=="vNext")throw new Error(`Expected vNext branch, got ${branch}`);

const baseline="856382812aac28b58df2eea0fad7f82d58f912d2";
const head=execSync("git rev-parse HEAD",{encoding:"utf8"}).trim();
try{execSync(`git merge-base --is-ancestor ${baseline} ${head}`,{stdio:"ignore"});}
catch{throw new Error(`Current HEAD ${head} does not descend from validated Foundation 02 checkpoint ${baseline}`);}

const file="supabase-privileged/002_evidence_worker_capability_role.sql";
const content="-- Supabase privileged setup: Evidence worker capability role 02\n--\n-- Run separately in the Supabase SQL Editor AFTER application migration 0018.\n-- Do NOT run with vnext_migrator: it intentionally has no CREATEROLE.\n--\n-- This creates a NOLOGIN capability role only. It contains no password/secret.\n-- A deployment-specific LOGIN principal may later be created out-of-band and\n-- granted membership in this role. Never make that principal BYPASSRLS.\n--\n-- IMPORTANT:\n-- Supabase SQL Editor may parse the entire multi-statement batch before executing\n-- the role-creation block. Therefore every later statement that references the\n-- newly created role is executed dynamically, after role creation has completed.\n\ndo $setup$\nbegin\n  if not exists(select 1 from pg_roles where rolname='vnext_evidence_worker') then\n    execute 'create role vnext_evidence_worker\n      nologin\n      nosuperuser\n      nocreatedb\n      nocreaterole\n      noreplication\n      nobypassrls';\n  end if;\n\n  execute 'alter role vnext_evidence_worker\n    nologin\n    nosuperuser\n    nocreatedb\n    nocreaterole\n    noreplication\n    nobypassrls';\n\n  execute 'revoke all on all tables in schema public from vnext_evidence_worker';\n  execute 'revoke all on all sequences in schema public from vnext_evidence_worker';\n  execute 'revoke all on schema public from vnext_evidence_worker';\n\n  execute 'grant usage on schema app_private to vnext_evidence_worker';\n\n  execute 'grant execute on function app_private.claim_evidence_worker_event(text,integer)\n    to vnext_evidence_worker';\n  execute 'grant execute on function app_private.complete_evidence_worker_event(uuid,uuid,text)\n    to vnext_evidence_worker';\n  execute 'grant execute on function app_private.fail_evidence_worker_event(uuid,uuid,text,text,integer)\n    to vnext_evidence_worker';\n  execute 'grant execute on function app_private.claim_evidence_processing(uuid,bigint,text,text)\n    to vnext_evidence_worker';\n  execute 'grant execute on function app_private.complete_evidence_processing(\n    uuid,bigint,uuid,text,text,text,bigint,text,text,text,bigint,text,boolean,text,text\n  ) to vnext_evidence_worker';\n  execute 'grant execute on function app_private.mark_evidence_original_deleted(uuid,bigint,text,text,text)\n    to vnext_evidence_worker';\n\n  execute 'revoke execute on function app_private.authorize_occurrence_evidence_read(uuid,text)\n    from vnext_evidence_worker';\n  execute 'revoke execute on function app_private.audit_evidence_read_url_issued(uuid,text,text,text)\n    from vnext_evidence_worker';\nend\n$setup$;\n";
fs.mkdirSync("supabase-privileged",{recursive:true});
fs.writeFileSync(file,content,"utf8");
console.log(`Replaced ${file} with SQL-Editor-safe dynamic role setup.`);

for(const artifact of fs.readdirSync(".")){
 if(/^APPLY-vnext-evidence-worker-role-sql-editor-fix-01\.(?:zip|mjs)$/i.test(artifact)){
  fs.unlinkSync(artifact);
  console.log(`Removed temporary artifact: ${artifact}`);
 }
}

execSync("git --no-pager diff --check",{stdio:"inherit"});
console.log("Worker role SQL Editor fix installed.");
console.log("Migration 0018 is already applied. Do NOT rerun it.");
