import fs from "node:fs";
import { execSync } from "node:child_process";

const branch = execSync("git branch --show-current", {encoding:"utf8"}).trim();
if (branch !== "vNext") throw new Error(`Expected vNext branch, got ${branch}`);

const validated = "c832ce1d5118b00db32f14cf7991c2479d279945";
const head = execSync("git rev-parse HEAD", {encoding:"utf8"}).trim();
try {
  execSync(`git merge-base --is-ancestor ${validated} ${head}`, {stdio:"ignore"});
} catch {
  throw new Error(`Current HEAD ${head} does not descend from validated baseline ${validated}`);
}

const path = "docs/VNEXT-PROJECT-CONTEXT.md";
if (!fs.existsSync(path)) throw new Error(`${path} is missing`);

let text = fs.readFileSync(path, "utf8");
if (!text.includes("c832ce1d5118b00db32f14cf7991c2479d279945")) {
  throw new Error("Expected Schedule + command-boundary baseline is not present in vNext context.");
}
if (!text.includes("Occurrence Foundation 01")) {
  throw new Error("Expected Occurrence Foundation 01 next target is not present in vNext context.");
}

// Remove trailing spaces/tabs without changing content semantics.
text = text
  .split(/\r?\n/)
  .map(line => line.replace(/[ \t]+$/g, ""))
  .join("\n");
if (!text.endsWith("\n")) text += "\n";
fs.writeFileSync(path, text, "utf8");
console.log("Removed trailing whitespace from vNext continuity document.");

for (const artifact of [
  "APPLY-vnext-context-after-schedule-hardening-01.zip",
  "APPLY-vnext-context-after-schedule-hardening-01.mjs",
  "APPLY-vnext-context-after-schedule-hardening-02.zip",
  "APPLY-vnext-context-after-schedule-hardening-02.mjs",
  "APPLY-vnext-context-after-schedule-hardening-03.zip",
  "APPLY-vnext-context-after-schedule-hardening-03.mjs"
]) {
  if (fs.existsSync(artifact)) {
    fs.unlinkSync(artifact);
    console.log(`Removed temporary artifact: ${artifact}`);
  }
}

execSync("git --no-pager diff --check", {stdio:"inherit"});

console.log("\n===== CONTEXT DIFF STAT =====");
execSync("git --no-pager diff --stat -- docs/VNEXT-PROJECT-CONTEXT.md", {stdio:"inherit"});
console.log("\n===== STATUS =====");
execSync("git status --short", {stdio:"inherit"});
console.log("\nContinuity cleanup 03 completed successfully.");
