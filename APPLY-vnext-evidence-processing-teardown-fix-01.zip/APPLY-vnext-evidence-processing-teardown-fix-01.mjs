import fs from "node:fs";
import {execSync} from "node:child_process";

const branch=execSync("git branch --show-current",{encoding:"utf8"}).trim();
if(branch!=="vNext")throw new Error(`Expected vNext branch, got ${branch}`);

const baseline="51d8e19c5bc417307cbecec18ca07153ed71238e";
const head=execSync("git rev-parse HEAD",{encoding:"utf8"}).trim();
try{execSync(`git merge-base --is-ancestor ${baseline} ${head}`,{stdio:"ignore"});}
catch{throw new Error(`Current HEAD ${head} does not descend from validated Evidence Storage baseline ${baseline}`);}

const file="tests/integration/evidence-capture-foundation.test.ts";
let s=fs.readFileSync(file,"utf8");

const oldText=`  if(ids.org){
   await migrator\`delete from audit_event where organization_id=\${ids.org}\`;
   await migrator\`delete from operation_idempotency where organization_id=\${ids.org}\`;`;

const newText=`  if(ids.org){
   await migrator\`delete from audit_event where organization_id=\${ids.org}\`;
   await migrator\`delete from outbox_event where organization_id=\${ids.org}\`;
   await migrator\`delete from operation_idempotency where organization_id=\${ids.org}\`;`;

if(s.includes(newText)){
 console.log("Evidence Capture teardown outbox cleanup already applied.");
}else{
 if(!s.includes(oldText))throw new Error("Expected Evidence Capture teardown anchor not found; refusing unsafe patch.");
 s=s.replace(oldText,newText);
 fs.writeFileSync(file,s,"utf8");
 console.log("Added outbox_event teardown cleanup to Evidence Capture integration suite.");
}

for(const artifact of fs.readdirSync(".")){
 if(/^APPLY-vnext-evidence-processing-teardown-fix-01\.(?:zip|mjs)$/i.test(artifact)){
  fs.unlinkSync(artifact);
  console.log(`Removed temporary artifact: ${artifact}`);
 }
}

execSync("git --no-pager diff --check",{stdio:"inherit"});
console.log("Teardown fix installed. No production code or database objects changed.");
console.log("Migration 0017 is already applied. Do NOT rerun it or any earlier migration.");
