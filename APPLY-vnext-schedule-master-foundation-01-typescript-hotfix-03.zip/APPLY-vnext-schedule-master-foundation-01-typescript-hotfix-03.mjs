import fs from "node:fs";
import { execSync } from "node:child_process";

const branch = execSync("git branch --show-current", { encoding: "utf8" }).trim();
if (branch !== "vNext") throw new Error(`Expected vNext branch, got ${branch}`);

const actionsFile = "src/lib/schedules/actions.ts";
const testFile = "tests/integration/schedule-master-foundation.test.ts";

for (const file of [actionsFile, testFile]) {
  if (!fs.existsSync(file)) throw new Error(`${file} is missing. Run the Schedule Master installer first.`);
}

let actions = fs.readFileSync(actionsFile, "utf8");

const oldBlock = `    const input = parseSchedule(formData);
    if (!input.scheduleId || !input.expectedVersion) throw new Error("Schedule version is required.");

    await withTenantContext(context, (tx) => tx\`
      select app_private.update_schedule_master(
        \${input.scheduleId},`;

const newBlock = `    const input = parseSchedule(formData);
    const scheduleId = input.scheduleId;
    const expectedVersion = input.expectedVersion;
    if (!scheduleId || !expectedVersion) throw new Error("Schedule version is required.");

    await withTenantContext(context, (tx) => tx\`
      select app_private.update_schedule_master(
        \${scheduleId},`;

if (actions.includes(newBlock)) {
  console.log("Schedule action narrowing hotfix is already present.");
} else {
  if (!actions.includes(oldBlock)) throw new Error("Expected updateSchedule narrowing anchor not found. Refusing to guess.");
  actions = actions.replace(oldBlock, newBlock);

  const oldExpected = "        ${input.expectedVersion}\n";
  const newExpected = "        ${expectedVersion}\n";
  if (!actions.includes(oldExpected)) throw new Error("Expected updateSchedule version argument anchor not found.");
  actions = actions.replace(oldExpected, newExpected);

  fs.writeFileSync(actionsFile, actions, "utf8");
  console.log("Fixed updateSchedule optional-value narrowing across transaction callback.");
}

let test = fs.readFileSync(testFile, "utf8");
const replacements = [
  [
    'areas.find(x=>x.site_id===ids.siteA).id',
    'areas.find(x=>x.site_id===ids.siteA)!.id',
  ],
  [
    'areas.find(x=>x.site_id===ids.siteB).id',
    'areas.find(x=>x.site_id===ids.siteB)!.id',
  ],
  [
    'tasks.find(x=>x.name==="Clean entrance glass").id',
    'tasks.find(x=>x.name==="Clean entrance glass")!.id',
  ],
  [
    'tasks.find(x=>x.name==="Restock lobby supplies").id',
    'tasks.find(x=>x.name==="Restock lobby supplies")!.id',
  ],
];

let testFixes = 0;
for (const [from, to] of replacements) {
  if (test.includes(to)) continue;
  if (!test.includes(from)) throw new Error(`Expected fixture lookup anchor missing: ${from}`);
  test = test.replace(from, to);
  testFixes += 1;
}
if (testFixes) {
  fs.writeFileSync(testFile, test, "utf8");
  console.log(`Hardened ${testFixes} deterministic fixture lookup(s) for TypeScript.`);
} else {
  console.log("Fixture lookup TypeScript hotfix is already present.");
}

execSync(
  "npx eslint src/lib/schedules/model.ts src/lib/schedules/server.ts src/lib/schedules/actions.ts src/app/workspace/schedules/page.tsx src/app/workspace/page.tsx src/app/demo/page.tsx tests/integration/schedule-master-foundation.test.ts tests/module/schedule-master-contract.test.ts tests/unit/schedule-intent.test.ts e2e/work-area-qr-demo.spec.ts scripts/db-apply-schedule-master-08.mjs",
  { stdio: "inherit" }
);
execSync("npm run typecheck", { stdio: "inherit" });
execSync("git --no-pager diff --check", { stdio: "inherit" });

console.log("Schedule Master TypeScript hotfix applied; focused ESLint, typecheck, and diff check passed.");
console.log("Next: npm run db:schedule-master:apply");
