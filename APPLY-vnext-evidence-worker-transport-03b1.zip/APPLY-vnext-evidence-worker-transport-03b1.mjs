import fs from "node:fs";
import path from "node:path";
import {execSync} from "node:child_process";

const branch=execSync("git branch --show-current",{encoding:"utf8"}).trim();
if(branch!=="vNext")throw new Error(`Expected vNext branch, got ${branch}`);

const baseline="64db7b13c53a7889ced755d7d7b4de929e4c8c57";
const head=execSync("git rev-parse HEAD",{encoding:"utf8"}).trim();
try{execSync(`git merge-base --is-ancestor ${baseline} ${head}`,{stdio:"ignore"});}
catch{throw new Error(`Current HEAD ${head} does not descend from validated Foundation 03A checkpoint ${baseline}`);}

const payloadRoot="APPLY-vnext-evidence-worker-transport-03b1-files";
if(!fs.existsSync(payloadRoot))throw new Error(`${payloadRoot} is missing. Unzip the complete 03B1 package first.`);

function copyTree(dir){
 for(const entry of fs.readdirSync(dir,{withFileTypes:true})){
  const src=path.join(dir,entry.name);
  const rel=path.relative(payloadRoot,src);
  const dst=rel;
  if(entry.isDirectory()){
   fs.mkdirSync(dst,{recursive:true});
   copyTree(src);
  }else{
   fs.mkdirSync(path.dirname(dst),{recursive:true});
   fs.copyFileSync(src,dst);
   console.log(`Wrote ${dst}`);
  }
 }
}
copyTree(payloadRoot);

function patchOnce(file,oldText,newText){
 let source=fs.readFileSync(file,"utf8");
 if(source.includes(newText)){
  console.log(`Already patched: ${file}`);
  return;
 }
 const count=source.split(oldText).length-1;
 if(count!==1)throw new Error(`Guarded anchor for ${file} expected once, found ${count}. Refusing unsafe patch.`);
 source=source.replace(oldText,newText);
 fs.writeFileSync(file,source,"utf8");
 console.log(`Updated ${file}`);
}

patchOnce(
 "package.json",
 `    "db:evidence-worker-read:apply": "node scripts/db-apply-evidence-worker-authorized-reads-18.mjs",
    "db:evidence-worker-role:grant": "node scripts/db-apply-evidence-worker-capability-grants.mjs"
`,
 `    "db:evidence-worker-read:apply": "node scripts/db-apply-evidence-worker-authorized-reads-18.mjs",
    "db:evidence-worker-transport:apply": "node scripts/db-apply-evidence-worker-transport-19.mjs",
    "db:evidence-worker-role:grant": "node scripts/db-apply-evidence-worker-capability-grants.mjs",
    "db:evidence-worker-storage-principal:register": "node scripts/db-register-evidence-worker-storage-principal.mjs",
    "worker:evidence:probe": "node worker/evidence-worker.mjs --probe"
`
);

patchOnce(
 ".env.example",
 `# Tests
TEST_DATABASE_URL=
`,
 `# Tests
TEST_DATABASE_URL=

# Evidence worker deployment (server-only; never prefix with NEXT_PUBLIC_)
# Provision only after migration 0019, worker capability re-grant, and Storage
# worker policies are verified. Do not commit .env.worker.local.
EVIDENCE_WORKER_DATABASE_URL=
EVIDENCE_WORKER_ID=
EVIDENCE_STORAGE_WORKER_EMAIL=
EVIDENCE_STORAGE_WORKER_PASSWORD=
`
);

const demoAnchor='<div className="demoBanner"><strong>Demo safety boundary</strong>';
const demoSection=' <section className="demoOperations"><span className="eyebrow">EVIDENCE WORKER TRANSPORT 03B1 DEMO</span><h2>Two least-privilege identities, bounded heartbeats, server-owned derivative paths</h2><div className="demoBehaviorGrid"><article><strong>Portable worker</strong><span>The Evidence processor is designed as a separate Node 22 container, not a long-running Next.js request. 03B1 exposes a transport/probe only; the real processing loop arrives with 03B2 codecs.</span></article><article><strong>Database identity</strong><span>A deployment LOGIN inherits only the NOLOGIN vnext_evidence_worker capability role. It remains non-BYPASSRLS and receives no direct tenant-table privileges.</span></article><article><strong>Storage machine principal</strong><span>A dedicated Supabase Auth machine account has no app_user or Organization Membership. Its auth.uid is mapped to one worker id, and worker-only Storage RLS additionally requires live queue and processing leases.</span></article><article><strong>Heartbeat safety</strong><span>Long media work renews bounded leases using the exact worker id and claim token. Expired or mismatched claims cannot be revived, so stale processors still fail closed.</span></article><article><strong>Server-owned derivatives</strong><span>The database issues exact normalized/preview paths: WebP for photos and MP4 plus JPEG poster for video. The worker cannot choose arbitrary tenant object keys.</span></article><article><strong>No universal Storage secret</strong><span>The worker uses the publishable key plus its dedicated authenticated machine session. No service-role key, JWT signing secret, or S3 static credential is introduced.</span></article></div></section>\n';
patchOnce("src/app/demo/page.tsx",demoAnchor,demoSection+demoAnchor);

patchOnce(
 "e2e/work-area-qr-demo.spec.ts",
 ` await expect(page.getByText(/signed URL, capped at 60 seconds/i)).toBeVisible();
});
`,
 ` await expect(page.getByText(/signed URL, capped at 60 seconds/i)).toBeVisible();
 await expect(page.getByText("EVIDENCE WORKER TRANSPORT 03B1 DEMO")).toBeVisible();
 await expect(page.getByText(/separate Node 22 container/i)).toBeVisible();
 await expect(page.getByText(/dedicated Supabase Auth machine account has no app_user or Organization Membership/i)).toBeVisible();
 await expect(page.getByText(/No service-role key, JWT signing secret, or S3 static credential/i)).toBeVisible();
});
`
);

fs.rmSync(payloadRoot,{recursive:true,force:true});
for(const artifact of [
 "APPLY-vnext-evidence-worker-transport-03b1.mjs",
 "APPLY-vnext-evidence-worker-transport-03b1.zip"
]){
 if(fs.existsSync(artifact)){
  fs.unlinkSync(artifact);
  console.log(`Removed temporary artifact: ${artifact}`);
 }
}

execSync("node --check scripts/db-apply-evidence-worker-transport-19.mjs",{stdio:"inherit"});
execSync("node --check scripts/db-apply-evidence-worker-capability-grants.mjs",{stdio:"inherit"});
execSync("node --check scripts/db-register-evidence-worker-storage-principal.mjs",{stdio:"inherit"});
execSync("node --check worker/lib/evidence-transport.mjs",{stdio:"inherit"});
execSync("node --check worker/evidence-worker.mjs",{stdio:"inherit"});
execSync("npm run typecheck",{stdio:"inherit"});
execSync("npm run lint",{stdio:"inherit"});
execSync("git --no-pager diff --check",{stdio:"inherit"});

console.log("Evidence Worker Transport & Storage Authorization Foundation 03B1 installed.");
console.log("Migration 0019 has NOT been applied yet.");
console.log("Do NOT rerun migration 0018 or earlier migrations.");
console.log("Do NOT run the updated worker-role grant until 0019 is applied.");
console.log("Supabase Storage worker policies have NOT been applied yet.");
console.log("No LOGIN credential, Auth machine user, service-role/secret API key, or S3 key was created.");
