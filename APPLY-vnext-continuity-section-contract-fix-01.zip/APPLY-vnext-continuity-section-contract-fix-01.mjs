import fs from "node:fs";
import {execSync} from "node:child_process";

const branch=execSync("git branch --show-current",{encoding:"utf8"}).trim();
if(branch!=="vNext")throw new Error(`Expected vNext branch, got ${branch}`);

const baseline="98f2ebaf7ad909e568cb686fdf3fcd16ddb87ca4";
const head=execSync("git rev-parse HEAD",{encoding:"utf8"}).trim();
try{execSync(`git merge-base --is-ancestor ${baseline} ${head}`,{stdio:"ignore"});}
catch{throw new Error(`Current HEAD ${head} does not descend from checkpoint ${baseline}`);}

const target="tests/module/work-area-qr-hardening-contract.test.ts";
let source=fs.readFileSync(target,"utf8");
const [oldText,newText]=Buffer.from("ICAgIGNvbnN0IGF1ZGl0ID0gY29udGV4dC5pbmRleE9mKCIjIyAxMC4gQXVkaXQgJiBPdXRib3giKTsKICAgIGNvbnN0IGRlbW8gPSBjb250ZXh0LmluZGV4T2YoIiMjIDExLiBEZW1vIFdvcmtzcGFjZSBSdWxlIOKAlCBNYW5kYXRvcnkiKTsKICAgIGNvbnN0IGJhc2VsaW5lID0gY29udGV4dC5pbmRleE9mKCIjIyAyMC4gQmFzZWxpbmUgQ29tbWl0IENoYWluIik7Ci0tLVBBSVItLS0KICAgIGNvbnN0IGF1ZGl0ID0gY29udGV4dC5pbmRleE9mKCIjIyAxMS4gQXVkaXQgJiBPdXRib3giKTsKICAgIGNvbnN0IGRlbW8gPSBjb250ZXh0LmluZGV4T2YoIiMjIDEyLiBEZW1vIFdvcmtzcGFjZSBSdWxlIOKAlCBNYW5kYXRvcnkiKTsKICAgIGNvbnN0IGJhc2VsaW5lID0gY29udGV4dC5pbmRleE9mKCIjIyAyMS4gQmFzZWxpbmUgQ29tbWl0IENoYWluIik7","base64").toString("utf8").split("\n---PAIR---\n");

if(source.includes(newText)){
 console.log("Continuity section-number contract is already current.");
}else{
 if(!source.includes(oldText))throw new Error("Expected stale continuity section-number block not found; refusing unexpected patch.");
 source=source.replace(oldText,newText);
 fs.writeFileSync(target,source,"utf8");
 console.log("Updated continuity section-number contract for inserted Occurrence Execution section.");
}

try{execSync("git restore --source=HEAD -- next-env.d.ts",{stdio:"ignore"});console.log("Restored generated next-env.d.ts.");}catch{}

for(const artifact of fs.readdirSync(".")){
 if(/^APPLY-vnext-continuity-section-contract-fix-01\.(?:zip|mjs)$/i.test(artifact)){
  fs.unlinkSync(artifact);console.log(`Removed temporary artifact: ${artifact}`);
 }
}

execSync("npm run typecheck",{stdio:"inherit"});
execSync("npm run lint",{stdio:"inherit"});
execSync("git --no-pager diff --check",{stdio:"inherit"});
console.log("Continuity section contract fix installed; typecheck, lint, and diff check passed.");
console.log("No database migration is included. Do NOT reapply migration 0013.");
