import fs from "node:fs";
import {execSync} from "node:child_process";

const branch=execSync("git branch --show-current",{encoding:"utf8"}).trim();
if(branch!=="vNext")throw new Error(`Expected vNext branch, got ${branch}`);

const baseline="72ea0dc63b9151229838506ea672775cb8b21472";
const head=execSync("git rev-parse HEAD",{encoding:"utf8"}).trim();
try{execSync(`git merge-base --is-ancestor ${baseline} ${head}`,{stdio:"ignore"});}
catch{throw new Error(`Current HEAD ${head} does not descend from checkpoint ${baseline}`);}

const target="tests/module/work-area-qr-hardening-contract.test.ts";
let source=fs.readFileSync(target,"utf8");
const oldLine='    expect(context).toContain("QR identity never grants application authorization");';
const newLine='    expect(context).toContain("QR identity never grants authorization");';

if(source.includes(newLine)){
  console.log("QR continuity wording contract is already current.");
}else{
  if(!source.includes(oldLine))throw new Error("Expected stale QR continuity wording was not found; refusing unexpected patch.");
  source=source.replace(oldLine,newLine);
  fs.writeFileSync(target,source,"utf8");
  console.log("Updated QR continuity wording contract to match the committed concise context.");
}

try{execSync("git restore --source=HEAD -- next-env.d.ts",{stdio:"ignore"});console.log("Restored generated next-env.d.ts.");}catch{}

for(const artifact of fs.readdirSync(".")){
 if(/^APPLY-vnext-qr-continuity-wording-test-fix-01\.(?:zip|mjs)$/i.test(artifact)){
  fs.unlinkSync(artifact);console.log(`Removed temporary artifact: ${artifact}`);
 }
}

execSync("npm run typecheck",{stdio:"inherit"});
execSync("npm run lint",{stdio:"inherit"});
execSync("git --no-pager diff --check",{stdio:"inherit"});
console.log("QR continuity wording test fix installed; typecheck, lint, and diff check passed.");
console.log("Migration 0013 is already applied. Do NOT reapply it.");
