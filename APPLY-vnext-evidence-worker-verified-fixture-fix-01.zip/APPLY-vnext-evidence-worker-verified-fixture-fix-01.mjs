import fs from "node:fs";
import {execSync} from "node:child_process";

const branch=execSync("git branch --show-current",{encoding:"utf8"}).trim();
if(branch!=="vNext")throw new Error(`Expected vNext branch, got ${branch}`);

const baseline="856382812aac28b58df2eea0fad7f82d58f912d2";
const head=execSync("git rev-parse HEAD",{encoding:"utf8"}).trim();
try{execSync(`git merge-base --is-ancestor ${baseline} ${head}`,{stdio:"ignore"});}
catch{throw new Error(`Current HEAD ${head} does not descend from validated Foundation 02 checkpoint ${baseline}`);}

const file="tests/integration/evidence-worker-authorized-reads.test.ts";
let s=fs.readFileSync(file,"utf8");

const oldColumns=`   content_type,byte_size,sha256_hex,verification_status,created_by_membership_id,storage_bucket,`;
const newColumns=`   content_type,byte_size,sha256_hex,verification_status,verified_at,created_by_membership_id,storage_bucket,`;

const oldValues=`   ${"${ids.orgA}"},${"${ids.siteA}"},${"${ids.wa}"},${"${ids.occ}"},${"${ids.occTask}"},'PHOTO',
   ${"${`${ids.orgA}/${ids.occ}/${ids.occTask}/original.jpg`}"},'image/jpeg',4096,${'${"a".repeat(64)}'},
   'VERIFIED',${"${ids.userM}"},'occurrence-evidence-private','UPLOADED',now(),'DONE',now(),now(),now(),`;

const newValues=`   ${"${ids.orgA}"},${"${ids.siteA}"},${"${ids.wa}"},${"${ids.occ}"},${"${ids.occTask}"},'PHOTO',
   ${"${`${ids.orgA}/${ids.occ}/${ids.occTask}/original.jpg`}"},'image/jpeg',4096,${'${"a".repeat(64)}'},
   'VERIFIED',now(),${"${ids.userM}"},'occurrence-evidence-private','UPLOADED',now(),'DONE',now(),now(),now(),`;

if(s.includes(newColumns)&&s.includes(newValues)){
 console.log("VERIFIED Evidence fixture timestamp fix already applied.");
}else{
 if(!s.includes(oldColumns))throw new Error("Evidence fixture column anchor not found; refusing unsafe patch.");
 if(!s.includes(oldValues))throw new Error("Evidence fixture value anchor not found; refusing unsafe patch.");
 s=s.replace(oldColumns,newColumns).replace(oldValues,newValues);
 fs.writeFileSync(file,s,"utf8");
 console.log("Added verified_at to the VERIFIED Evidence integration fixture.");
}

for(const artifact of fs.readdirSync(".")){
 if(/^APPLY-vnext-evidence-worker-verified-fixture-fix-01\.(?:zip|mjs)$/i.test(artifact)){
  fs.unlinkSync(artifact);
  console.log(`Removed temporary artifact: ${artifact}`);
 }
}

execSync("git --no-pager diff --check",{stdio:"inherit"});
console.log("Evidence worker VERIFIED fixture fix installed.");
console.log("No production source, role grants, or database migration changed.");
console.log("Migration 0018 and the worker capability role are already provisioned; do NOT rerun them.");
