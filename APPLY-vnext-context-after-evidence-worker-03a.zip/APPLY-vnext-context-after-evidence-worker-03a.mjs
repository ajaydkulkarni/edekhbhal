import fs from "node:fs";
import {execSync} from "node:child_process";

const branch=execSync("git branch --show-current",{encoding:"utf8"}).trim();
if(branch!=="vNext")throw new Error(`Expected vNext branch, got ${branch}`);

const baseline="64db7b13c53a7889ced755d7d7b4de929e4c8c57";
const head=execSync("git rev-parse HEAD",{encoding:"utf8"}).trim();
try{execSync(`git merge-base --is-ancestor ${baseline} ${head}`,{stdio:"ignore"});}
catch{throw new Error(`Current HEAD ${head} does not descend from validated Foundation 03A checkpoint ${baseline}`);}

const file="docs/VNEXT-PROJECT-CONTEXT.md";
let s=fs.readFileSync(file,"utf8");

function replaceOnce(oldText,newText,label){
 if(s.includes(newText)){console.log(`Already current: ${label}`);return;}
 const count=s.split(oldText).length-1;
 if(count!==1)throw new Error(`${label}: expected exactly one anchor, found ${count}. Refusing unsafe patch.`);
 s=s.replace(oldText,newText);
 console.log(`Updated: ${label}`);
}

replaceOnce(
"**Latest validated vNext baseline:** `856382812aac28b58df2eea0fad7f82d58f912d2` — `Add Evidence Verification and Media Normalization Foundation`",
"**Latest validated vNext baseline:** `64db7b13c53a7889ced755d7d7b4de929e4c8c57` — `Add Evidence Worker Queue and Authorized Reads Foundation 03A`",
"validated baseline header"
);

replaceOnce(
`- \`vnext_runtime\`
  - no superuser
  - no \`BYPASSRLS\`
  - no database CREATE privilege
  - least-privilege grants only`,
`- \`vnext_runtime\`
  - no superuser
  - no \`BYPASSRLS\`
  - no database CREATE privilege
  - least-privilege grants only
- \`vnext_evidence_worker\`
  - NOLOGIN capability role
  - no superuser / CREATEDB / CREATEROLE / REPLICATION / \`BYPASSRLS\`
  - no direct sensitive-table privileges
  - \`app_private\` USAGE plus only exact Evidence worker command EXECUTE grants
  - cannot invoke application Evidence-read authorization/audit commands
  - deployment-specific LOGIN principal/credential is still deferred`,
"worker capability role"
);

replaceOnce(
`Evidence upload plus the processor control-plane foundation are implemented. A dedicated worker identity, real media codecs/derivative generation, object deletion execution, and authorized operational read delivery remain deferred.`,
`Evidence capture, the processor control plane, the leased Evidence outbox queue, the NOLOGIN worker capability role, and the application-authorized read boundary are implemented. A deployed LOGIN worker transport, real media codecs/derivative generation, Storage machine credential boundary, and real object deletion execution remain deferred.`,
"task execution evidence status"
);

const processingTail=`- Demo illustrates queued, leased, verified/rejected processing without real media writes

Still required before the evidence pipeline is production-complete:

- provision a dedicated least-privilege processor identity
- implement a deployed worker that consumes the outbox safely
- real optimized/compressed image derivative generation
- real video normalization/transcoding and poster/thumbnail generation
- Storage write policy/credential boundary for normalized and preview objects
- execute and confirm queued original-object deletion
- short-lived signed operational reads after application authorization
- ADMIN/SITE_MANAGER Site-scoped and assigned USER evidence-view UX
- real Storage transport/media processing end-to-end and load certification`;

const processingNew=`- Demo illustrates queued, leased, verified/rejected processing without real media writes

Evidence Worker Queue & Authorized Reads Foundation 03A commit:

\`64db7b13c53a7889ced755d7d7b4de929e4c8c57\` — \`Add Evidence Worker Queue and Authorized Reads Foundation 03A\`

Migration:

- \`0018_evidence_worker_authorized_reads.sql\`

Migration \`0018\` is already applied to the active vNext database. **Do not reapply it.**

Privileged worker capability setup is also already provisioned. **Do not recreate/regrant it unless a later migration explicitly changes the contract.**

Implemented 03A boundary:

- Evidence-only transactional outbox claims use \`FOR UPDATE SKIP LOCKED\`
- queue claims carry worker id, random claim token, bounded lease, attempt count, last-attempt timestamp, and retry delay
- stale/mismatched worker event claims fail closed
- normal \`vnext_runtime\` cannot execute worker queue/deletion commands
- dedicated \`vnext_evidence_worker\` capability role is NOLOGIN and non-BYPASSRLS
- the worker capability role has no direct sensitive-table grants
- function ownership is deliberately split: Supabase project \`postgres\` creates/verifies the role; \`vnext_migrator\`, which owns \`app_private\`, grants exact command EXECUTE privileges
- no worker password, frontend service-role key, or universal Storage credential was introduced
- queued original deletion can be acknowledged only for the exact VERIFIED Evidence/version/object key and is idempotently audited
- application command authorizes Evidence reads before Storage signing
- ADMIN is Organization-wide; SITE_MANAGER remains Site-scoped; USER requires assigned Occurrence + Site scope
- \`BEST\` read prefers preview, then normalized, then retained original
- deleted originals cannot be requested
- signed operational URLs are capped at 60 seconds
- signed-read issuance is audited
- public QR has no private Evidence route
- My Work and Occurrences expose short-lived private Evidence view links
- Demo illustrates worker leases, least privilege, authorized reads, deletion acknowledgement, and the public-QR boundary
- global worker-queue regression fixtures are deterministic under parallel Vitest execution

Still required before the evidence pipeline is production-complete:

- select and deploy the actual worker runtime
- create a deployment-specific least-privilege LOGIN principal/secret bound to the worker capability role; never grant BYPASSRLS
- define the isolated machine Storage credential/policy boundary for original download and normalized/preview upload/delete
- independently fetch and validate actual source MIME/size/SHA-256 in the deployed worker
- real optimized/compressed image derivative generation
- real video normalization/transcoding and poster/thumbnail generation
- upload normalized/preview objects to server-owned tenant-scoped keys
- execute real Storage deletion for \`EVIDENCE_ORIGINAL_DELETE_REQUESTED\`, then call the acknowledgement command
- live authenticated Storage signed-read transport E2E, including URL expiry
- duplicate outbox delivery/restart/backoff certification against the deployed worker
- real Storage/media processing end-to-end and production load/SLO certification`;

replaceOnce(processingTail,processingNew,"Foundation 03A evidence section");

replaceOnce(
`Validated operational audit includes onboarding, Work Area/QR, Task, Schedule, occurrence claim/start, and supersession.`,
`Validated operational audit includes onboarding, Work Area/QR, Task, Schedule, occurrence claim/start/supersession, Evidence intent/upload, processor verification/rejection, original-deletion acknowledgement, and signed-read issuance.`,
"audit coverage"
);

const start17=s.indexOf("## 17. Current Validated Test Baseline");
const end17=s.indexOf("\n---\n\n## 18. Current Technology Baseline",start17);
if(start17<0||end17<0)throw new Error("Could not locate Section 17 boundaries.");
const new17=`## 17. Current Validated Test Baseline

At commit \`64db7b13c53a7889ced755d7d7b4de929e4c8c57\`:

### Integration

- Database Foundation RLS: **13/13 PASS**
- Auth + Onboarding: **6/6 PASS**
- Work Area + QR foundation: **7/7 PASS**
- Work Area + QR hardening: **6/6 PASS**
- Task Master Foundation: **8/8 PASS**
- Schedule Master Foundation: **8/8 PASS**
- Task/Schedule command-boundary hardening: **3/3 PASS**
- Occurrence Foundation: **5/5 PASS**
- Occurrence Execution & Supersession: **7/7 PASS**
- Occurrence Execution Security Hardening: **12/12 PASS**
- Occurrence Task Execution & Completion + hardening: **14/14 PASS**
- Evidence Capture & Storage hardening: **10/10 PASS**
- Evidence Verification & Media Normalization Foundation 02: **6/6 PASS**
- Evidence Worker Queue & Authorized Reads Foundation 03A: **6/6 PASS**
- Total integration: **111/111 PASS**

### Full Vitest

- Test files: **36/36 PASS**
- Tests: **181/181 PASS**

### Build gates

- TypeScript: **PASS**
- ESLint: **PASS**
- Next.js production build: **PASS**
- Generated routes: **17/17**
- \`git diff --check\`: **PASS**

Validated routes include:

- \`/\`
- \`/demo\`
- \`/login\`
- \`/register\`
- \`/auth/callback\`
- onboarding routes
- \`/workspace\`
- \`/workspace/my-work\`
- \`/workspace/tasks\`
- \`/workspace/schedules\`
- \`/workspace/occurrences\`
- \`/workspace/evidence/[id]\`
- \`/workspace/work-areas\`
- \`/workspace/work-areas/[id]/qr\`
- \`/q/[token]\`

### Playwright

- **3/3 PASS**
- Demo regression covers planning, My Work / claim / QR-start / supersession, sequential Task execution/completion, Evidence upload/verification gating, expired-intent/wrong-object fail-closed behavior, queued/leased processor behavior, verification/normalization safety boundaries, worker least privilege, 60-second authorized reads, public-QR Evidence isolation, and idempotency/security explanation
`;
s=s.slice(0,start17)+new17+s.slice(end17);
console.log("Updated: validated test baseline");

const start19=s.indexOf("## 19. Immediate Next Development Target");
const end19=s.indexOf("\n---\n\n## 20. Important Deferred Items",start19);
if(start19<0||end19<0)throw new Error("Could not locate Section 19 boundaries.");
const new19=`## 19. Immediate Next Development Target

Next increment:

**Evidence Processing Worker Transport & Media Normalization Foundation 03B**

Build on validated 03A without weakening tenant isolation, the NOLOGIN capability-role contract, outbox lease/idempotency behavior, Storage isolation, Evidence history, signed-read authorization, or the VERIFIED Task gate.

Target foundation:

- choose a deployable worker runtime explicitly; do not hide long-running media processing inside a Next.js request
- provision a deployment-specific LOGIN principal that inherits only \`vnext_evidence_worker\`; no superuser and no BYPASSRLS
- define and isolate the machine Storage credential boundary separately from browser/runtime credentials
- consume \`EVIDENCE_PROCESS_REQUESTED\` using the 03A leased queue with retry/backoff, duplicate-delivery safety, and crash recovery
- fetch the exact private original object and independently validate actual MIME, byte size, and SHA-256
- generate optimized PHOTO derivatives and preview using a production-supported image codec
- generate normalized MP4 plus poster/preview for VIDEO using a production-supported media processor
- upload only to server-owned Organization-scoped derivative keys
- complete VERIFIED/REJECTED through the existing processor command boundary
- consume \`EVIDENCE_ORIGINAL_DELETE_REQUESTED\`, delete the exact original from Storage, then acknowledge \`DELETED\`
- preserve original on processing rejection/failure
- add live authenticated signed-read transport tests including expiry and unauthorized/cross-tenant denial
- add regressions for worker credential escape, cross-tenant object keys, object tampering, duplicate deliveries, stale leases/tokens, restart recovery, deletion retry, and derivative upload failure
- Demo remains synthetic/read-only

Keep mobile camera UX, claim expiry, priority ranking, reported work, billing, and unrelated platform-control work separate unless the worker transport contract requires them.
`;
s=s.slice(0,start19)+new19+s.slice(end19);
console.log("Updated: immediate next target");

replaceOnce(
`- deployed evidence processing worker, real media normalization codecs, original-object deletion execution, and authorized evidence-view delivery`,
`- deployed Evidence processor runtime, deployment-specific worker LOGIN/secret, real media normalization codecs, machine Storage credential boundary, real original-object deletion execution, and live signed-read transport certification`,
"deferred evidence item"
);

replaceOnce(
`- \`8563828\` — Add Evidence Verification and Media Normalization Foundation

\`856382812aac28b58df2eea0fad7f82d58f912d2\` is the current locked validated vNext baseline.`,
`- \`8563828\` — Add Evidence Verification and Media Normalization Foundation
- \`64db7b1\` — Add Evidence Worker Queue and Authorized Reads Foundation 03A

\`64db7b13c53a7889ced755d7d7b4de929e4c8c57\` is the current locked validated vNext baseline.`,
"baseline chain"
);

fs.writeFileSync(file,s,"utf8");

for(const artifact of fs.readdirSync(".")){
 if(/^APPLY-vnext-context-after-evidence-worker-03a\.(?:zip|mjs)$/i.test(artifact)){
  fs.unlinkSync(artifact);
  console.log(`Removed temporary artifact: ${artifact}`);
 }
}

execSync("git --no-pager diff --check",{stdio:"inherit"});
console.log("vNext continuity updated for validated Evidence Worker Queue & Authorized Reads Foundation 03A.");
console.log("Migration 0018 is already applied. Do NOT rerun it.");
console.log("The NOLOGIN worker capability role and exact grants are already provisioned. Do NOT recreate/regrant them.");
