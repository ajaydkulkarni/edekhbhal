import fs from "node:fs";
import {execSync} from "node:child_process";

const branch=execSync("git branch --show-current",{encoding:"utf8"}).trim();
if(branch!=="vNext")throw new Error(`Expected vNext branch, got ${branch}`);

const baseline="856382812aac28b58df2eea0fad7f82d58f912d2";
const head=execSync("git rev-parse HEAD",{encoding:"utf8"}).trim();
try{execSync(`git merge-base --is-ancestor ${baseline} ${head}`,{stdio:"ignore"});}
catch{throw new Error(`Current HEAD ${head} does not descend from validated Foundation 02 checkpoint ${baseline}`);}

const file="tests/integration/evidence-worker-authorized-reads.test.ts";
if(!fs.existsSync(file))throw new Error(`${file} is missing; refusing unsafe patch.`);
let s=fs.readFileSync(file,"utf8");

const oldInsert=`  const event=(await migrator\`insert into outbox_event(
   organization_id,event_type,aggregate_type,aggregate_id,payload_json,idempotency_key
  ) values(\${ids.orgA},'EVIDENCE_PROCESS_REQUESTED','ScheduleOccurrenceEvidence',\${ids.evidence},'{}'::jsonb,\${crypto.randomUUID()}) returning id\`)[0].id;`;

const newInsert=`  // The worker queue is intentionally global across Organizations. Give this
  // fixture an earlier available_at so concurrent integration suites cannot
  // legitimately win the same global queue claim.
  const event=(await migrator\`insert into outbox_event(
   organization_id,event_type,aggregate_type,aggregate_id,payload_json,idempotency_key,available_at
  ) values(
   \${ids.orgA},'EVIDENCE_PROCESS_REQUESTED','ScheduleOccurrenceEvidence',\${ids.evidence},
   '{}'::jsonb,\${crypto.randomUUID()},'2000-01-01T00:00:00Z'
  ) returning id\`)[0].id;`;

const oldDeleteInsert=`  const event=(await migrator\`insert into outbox_event(
   organization_id,event_type,aggregate_type,aggregate_id,payload_json,idempotency_key
  ) values(\${ids.orgA},'EVIDENCE_ORIGINAL_DELETE_REQUESTED','ScheduleOccurrenceEvidence',\${ids.evidence},'{}'::jsonb,\${crypto.randomUUID()}) returning id\`)[0].id;`;

const newDeleteInsert=`  // Keep this global-queue fixture deterministic while other integration
  // suites are concurrently producing real Evidence outbox events.
  const event=(await migrator\`insert into outbox_event(
   organization_id,event_type,aggregate_type,aggregate_id,payload_json,idempotency_key,available_at
  ) values(
   \${ids.orgA},'EVIDENCE_ORIGINAL_DELETE_REQUESTED','ScheduleOccurrenceEvidence',\${ids.evidence},
   '{}'::jsonb,\${crypto.randomUUID()},'2000-01-01T00:00:00Z'
  ) returning id\`)[0].id;`;

if(s.includes(newInsert)&&s.includes(newDeleteInsert)){
 console.log("Global worker-queue test isolation fix already applied.");
}else{
 if(!s.includes(oldInsert))throw new Error("Process-request outbox fixture anchor not found; refusing unsafe patch.");
 if(!s.includes(oldDeleteInsert))throw new Error("Original-delete outbox fixture anchor not found; refusing unsafe patch.");
 s=s.replace(oldInsert,newInsert).replace(oldDeleteInsert,newDeleteInsert);
 fs.writeFileSync(file,s,"utf8");
 console.log("Made the two worker-queue fixtures deterministic under parallel Vitest execution.");
}

for(const artifact of fs.readdirSync(".")){
 if(/^APPLY-vnext-evidence-worker-global-queue-test-isolation-fix-01\.(?:zip|mjs)$/i.test(artifact)){
  fs.unlinkSync(artifact);
  console.log(`Removed temporary artifact: ${artifact}`);
 }
}

execSync("git --no-pager diff --check",{stdio:"inherit"});
console.log("Worker global-queue test isolation fix installed.");
console.log("No production source, database migration, or worker-role grant changed.");
console.log("Migration 0018 and the worker capability role are already provisioned; do NOT rerun them.");
