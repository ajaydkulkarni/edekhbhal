import fs from "node:fs";
import { execSync } from "node:child_process";

const branch = execSync("git branch --show-current", { encoding: "utf8" }).trim();
if (branch !== "vNext") throw new Error(`Expected vNext branch, got ${branch}`);

const actionsFile = "src/lib/schedules/actions.ts";
const testFile = "tests/integration/schedule-master-foundation.test.ts";
for (const file of [actionsFile, testFile]) {
  if (!fs.existsSync(file)) throw new Error(`${file} is missing. Run the Schedule Master installer first.`);
}

// ---- Fix updateSchedule using function-scoped semantic anchors, not formatting-sensitive blocks.
let actions = fs.readFileSync(actionsFile, "utf8");
const start = actions.indexOf("export async function updateSchedule");
const end = actions.indexOf("export async function toggleScheduleStatus", start);
if (start < 0 || end < 0) throw new Error("Could not isolate updateSchedule(). Refusing to guess.");

let segment = actions.slice(start, end);

if (!segment.includes("const scheduleId=input.scheduleId") && !segment.includes("const scheduleId = input.scheduleId")) {
  const guard = /if\s*\(\s*!input\.scheduleId\s*\|\|\s*!input\.expectedVersion\s*\)\s*throw new Error\("Schedule version is required\."\)\s*;?/;
  if (!guard.test(segment)) throw new Error("Expected Schedule version guard was not found.");
  segment = segment.replace(
    guard,
    'const scheduleId=input.scheduleId,expectedVersion=input.expectedVersion;if(!scheduleId||!expectedVersion)throw new Error("Schedule version is required.");'
  );
  console.log("Added stable local narrowing for scheduleId and expectedVersion.");
} else {
  console.log("Schedule action narrowing locals already exist.");
}

let scheduleIdReplacements = 0;
let versionReplacements = 0;
segment = segment.replace(/\$\{input\.scheduleId\}/g, () => {
  scheduleIdReplacements += 1;
  return "${scheduleId}";
});
segment = segment.replace(/\$\{input\.expectedVersion\}/g, () => {
  versionReplacements += 1;
  return "${expectedVersion}";
});

if (!segment.includes("${scheduleId}") || !segment.includes("${expectedVersion}")) {
  throw new Error("Narrowed Schedule arguments were not found after repair.");
}

actions = actions.slice(0, start) + segment + actions.slice(end);
fs.writeFileSync(actionsFile, actions, "utf8");
console.log(`Updated transaction arguments (${scheduleIdReplacements} scheduleId, ${versionReplacements} expectedVersion replacement(s)).`);

// ---- Fix deterministic fixture lookups.
let test = fs.readFileSync(testFile, "utf8");
const fixturePatterns = [
  [
    /areas\.find\(\s*x\s*=>\s*x\.site_id\s*===\s*ids\.siteA\s*\)(?!\!)\.id/g,
    "areas.find(x=>x.site_id===ids.siteA)!.id",
    "siteA Work Area"
  ],
  [
    /areas\.find\(\s*x\s*=>\s*x\.site_id\s*===\s*ids\.siteB\s*\)(?!\!)\.id/g,
    "areas.find(x=>x.site_id===ids.siteB)!.id",
    "siteB Work Area"
  ],
  [
    /tasks\.find\(\s*x\s*=>\s*x\.name\s*===\s*"Clean entrance glass"\s*\)(?!\!)\.id/g,
    'tasks.find(x=>x.name==="Clean entrance glass")!.id',
    "first Task"
  ],
  [
    /tasks\.find\(\s*x\s*=>\s*x\.name\s*===\s*"Restock lobby supplies"\s*\)(?!\!)\.id/g,
    'tasks.find(x=>x.name==="Restock lobby supplies")!.id',
    "second Task"
  ],
];

let fixtureFixes = 0;
for (const [pattern, replacement, label] of fixturePatterns) {
  if (pattern.test(test)) {
    pattern.lastIndex = 0;
    test = test.replace(pattern, replacement);
    fixtureFixes += 1;
    console.log(`Narrowed deterministic fixture lookup: ${label}.`);
  }
}
fs.writeFileSync(testFile, test, "utf8");
console.log(`Fixture lookup repairs applied: ${fixtureFixes}.`);

execSync(
  "npx eslint src/lib/schedules/model.ts src/lib/schedules/server.ts src/lib/schedules/actions.ts src/app/workspace/schedules/page.tsx src/app/workspace/page.tsx src/app/demo/page.tsx tests/integration/schedule-master-foundation.test.ts tests/module/schedule-master-contract.test.ts tests/unit/schedule-intent.test.ts e2e/work-area-qr-demo.spec.ts scripts/db-apply-schedule-master-08.mjs",
  { stdio: "inherit" }
);
execSync("npm run typecheck", { stdio: "inherit" });
execSync("git --no-pager diff --check", { stdio: "inherit" });

console.log("Schedule Master TypeScript hotfix 04 applied; focused ESLint, typecheck, and diff check passed.");
console.log("Do not run the database migration until this output is reviewed.");
