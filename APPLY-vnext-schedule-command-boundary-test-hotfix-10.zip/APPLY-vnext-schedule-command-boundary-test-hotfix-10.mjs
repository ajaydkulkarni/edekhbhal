import fs from "node:fs";
import { execSync } from "node:child_process";

const branch=execSync("git branch --show-current",{encoding:"utf8"}).trim();
if(branch!=="vNext") throw new Error(`Expected vNext branch, got ${branch}`);

const file="tests/integration/schedule-master-foundation.test.ts";
if(!fs.existsSync(file)) throw new Error(`${file} is missing.`);

let source=fs.readFileSync(file,"utf8");
const oldLine=`   const write=await asUser(tx=>tx\`update schedule_master set name='Forbidden' where id=\${ids.schedule} returning id\`);expect(write).toHaveLength(0);`;
const newLine=`   await expect(asUser(tx=>tx\`update schedule_master set name='Forbidden' where id=\${ids.schedule} returning id\`)).rejects.toThrow(/permission denied/i);`;

if(source.includes(newLine)){
  console.log("Schedule direct-DML regression already expects permission denial.");
}else{
  if(!source.includes(oldLine)) throw new Error("Expected Schedule direct-update regression anchor not found.");
  source=source.replace(oldLine,newLine);
  fs.writeFileSync(file,source,"utf8");
  console.log("Updated Schedule regression for revoked direct runtime UPDATE.");
}

execSync(`npx eslint "${file}"`,{stdio:"inherit"});
execSync("npm run typecheck",{stdio:"inherit"});
execSync("git --no-pager diff --check",{stdio:"inherit"});
console.log("Schedule least-privilege regression hotfix passed ESLint, typecheck, and diff check.");
console.log("Do NOT reapply migration 0009. Rerun the focused hardening tests.");
