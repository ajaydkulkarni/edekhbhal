import fs from "node:fs";
import { execSync } from "node:child_process";

const branch = execSync("git branch --show-current", { encoding: "utf8" }).trim();
if (branch !== "vNext") throw new Error(`Expected vNext branch, got ${branch}`);

const actionsFile = "src/lib/schedules/actions.ts";
const testFile = "tests/integration/schedule-master-foundation.test.ts";
for (const file of [actionsFile, testFile]) {
  if (!fs.existsSync(file)) throw new Error(`${file} is missing.`);
}

let actions = fs.readFileSync(actionsFile, "utf8");

const actionAnchors = [
  [
    'const i=parse(formData);if(!i.scheduleId||!i.expectedVersion)throw new Error("Schedule version is required.");',
    'const i=parse(formData),scheduleId=i.scheduleId,expectedVersion=i.expectedVersion;if(!scheduleId||!expectedVersion)throw new Error("Schedule version is required.");'
  ],
  [
    '${i.scheduleId},${i.workAreaId},${i.name},${i.documentReference},${i.documentRevision},${i.frequencyType}::schedule_frequency_type,',
    '${scheduleId},${i.workAreaId},${i.name},${i.documentReference},${i.documentRevision},${i.frequencyType}::schedule_frequency_type,'
  ],
  [
    '${i.localDate}::date,${i.localTime}::time,${i.recurrence.endLocalDate}::date,${JSON.stringify(i.tasks)}::jsonb,${i.expectedVersion})`);',
    '${i.localDate}::date,${i.localTime}::time,${i.recurrence.endLocalDate}::date,${JSON.stringify(i.tasks)}::jsonb,${expectedVersion})`);'
  ],
];

for (const [before, after] of actionAnchors) {
  if (actions.includes(after)) continue;
  if (!actions.includes(before)) throw new Error(`Expected actions.ts anchor not found:\n${before}`);
  actions = actions.replace(before, after);
}
fs.writeFileSync(actionsFile, actions, "utf8");
console.log("Updated updateSchedule() with callback-stable narrowed locals.");

let test = fs.readFileSync(testFile, "utf8");

const testAnchors = [
  [
    'ids.workAreaA=areas.find(x=>x.site_id===ids.siteA).id;ids.workAreaB=areas.find(x=>x.site_id===ids.siteB).id;',
    'ids.workAreaA=areas.find(x=>x.site_id===ids.siteA)!.id;ids.workAreaB=areas.find(x=>x.site_id===ids.siteB)!.id;'
  ],
  [
    'ids.taskA=tasks.find(x=>x.name==="Clean entrance glass").id;ids.taskB=tasks.find(x=>x.name==="Restock lobby supplies").id;',
    'ids.taskA=tasks.find(x=>x.name==="Clean entrance glass")!.id;ids.taskB=tasks.find(x=>x.name==="Restock lobby supplies")!.id;'
  ],
];

for (const [before, after] of testAnchors) {
  if (test.includes(after)) continue;
  if (!test.includes(before)) throw new Error(`Expected integration-test anchor not found:\n${before}`);
  test = test.replace(before, after);
}
fs.writeFileSync(testFile, test, "utf8");
console.log("Updated deterministic fixture lookups with TypeScript non-null assertions.");

execSync(
  "npx eslint src/lib/schedules/actions.ts tests/integration/schedule-master-foundation.test.ts",
  { stdio: "inherit" }
);
execSync("npm run typecheck", { stdio: "inherit" });
execSync("git --no-pager diff --check", { stdio: "inherit" });

console.log("Schedule Master local-state TypeScript hotfix passed ESLint, full typecheck, and diff check.");
console.log("Do not run the database migration until this result is reviewed.");
