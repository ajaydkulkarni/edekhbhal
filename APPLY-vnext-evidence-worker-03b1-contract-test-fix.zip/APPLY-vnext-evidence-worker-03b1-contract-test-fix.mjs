import fs from "node:fs";
import {execSync} from "node:child_process";

const branch=execSync("git branch --show-current",{encoding:"utf8"}).trim();
if(branch!=="vNext")throw new Error(`Expected vNext branch, got ${branch}`);

const file="tests/module/evidence-worker-authorized-reads-contract.test.ts";
const oldLine='  expect(grants).toContain("no direct sensitive-table grants");';
const newLine='  expect(grants).toMatch(/no direct sensitive-table grants/i);';

let source=fs.readFileSync(file,"utf8");

if(source.includes(newLine)){
  console.log("03B1 contract-test case-sensitivity fix is already applied.");
}else{
  const count=source.split(oldLine).length-1;
  if(count!==1){
    throw new Error(`Expected the stale case-sensitive assertion exactly once, found ${count}. Refusing unsafe patch.`);
  }
  source=source.replace(oldLine,newLine);
  fs.writeFileSync(file,source,"utf8");
  console.log(`Updated ${file}`);
}

for(const artifact of [
  "APPLY-vnext-evidence-worker-03b1-contract-test-fix.zip",
  "APPLY-vnext-evidence-worker-03b1-contract-test-fix.mjs"
]){
  if(fs.existsSync(artifact)){
    fs.unlinkSync(artifact);
    console.log(`Removed temporary artifact: ${artifact}`);
  }
}

execSync("npx vitest run tests/module/evidence-worker-authorized-reads-contract.test.ts tests/module/evidence-worker-transport-foundation-contract.test.ts",{stdio:"inherit"});
execSync("git --no-pager diff --check",{stdio:"inherit"});

console.log("03B1 contract-test compatibility fix applied and focused module tests passed.");
console.log("No database migration, role grant, Storage policy, or credential was changed.");
