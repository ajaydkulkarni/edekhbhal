import fs from "node:fs";
import {execSync} from "node:child_process";

const branch=execSync("git branch --show-current",{encoding:"utf8"}).trim();
if(branch!=="vNext")throw new Error(`Expected vNext branch, got ${branch}`);

const baseline="72ea0dc63b9151229838506ea672775cb8b21472";
const head=execSync("git rev-parse HEAD",{encoding:"utf8"}).trim();
try{execSync(`git merge-base --is-ancestor ${baseline} ${head}`,{stdio:"ignore"});}
catch{throw new Error(`Current HEAD ${head} does not descend from checkpoint ${baseline}`);}

const target="tests/integration/occurrence-foundation.test.ts";
if(!fs.existsSync(target))throw new Error("Occurrence Foundation integration test is missing.");

const [oldText,newText]=Buffer.from("ICBjb25zdCBhZnRlcj1hd2FpdCBhc1VzZXIodHg9PnR4YHNlbGVjdCBzdGF0dXMsc2NoZWR1bGVfbmFtZV9zbmFwc2hvdCBmcm9tIHNjaGVkdWxlX29jY3VycmVuY2Ugd2hlcmUgaWQ9JHtvY2N1cnJlbmNlWzBdLmlkfWApOwogIGV4cGVjdChhZnRlclswXSkudG9NYXRjaE9iamVjdCh7c3RhdHVzOiJDT01QTEVURUQiLHNjaGVkdWxlX25hbWVfc25hcHNob3Q6Ikhpc3RvcnkgU2NoZWR1bGUifSk7Ci0tLVNQTElULS0tCiAgY29uc3QgYWZ0ZXI9YXdhaXQgYXNBZG1pbih0eD0+dHhgc2VsZWN0IHN0YXR1cyxzY2hlZHVsZV9uYW1lX3NuYXBzaG90IGZyb20gc2NoZWR1bGVfb2NjdXJyZW5jZSB3aGVyZSBpZD0ke29jY3VycmVuY2VbMF0uaWR9YCk7CiAgZXhwZWN0KGFmdGVyWzBdKS50b01hdGNoT2JqZWN0KHtzdGF0dXM6IkNPTVBMRVRFRCIsc2NoZWR1bGVfbmFtZV9zbmFwc2hvdDoiSGlzdG9yeSBTY2hlZHVsZSJ9KTsKCiAgY29uc3QgdXNlckhpc3Rvcnk9YXdhaXQgYXNVc2VyKHR4PT50eGBzZWxlY3QgaWQgZnJvbSBzY2hlZHVsZV9vY2N1cnJlbmNlIHdoZXJlIGlkPSR7b2NjdXJyZW5jZVswXS5pZH1gKTsKICBleHBlY3QodXNlckhpc3RvcnkpLnRvSGF2ZUxlbmd0aCgwKTs=","base64").toString("utf8").split("\n---SPLIT---\n");
let source=fs.readFileSync(target,"utf8");
if(source.includes(newText)){
  console.log("Occurrence history visibility regression test is already updated.");
}else{
  if(!source.includes(oldText))throw new Error("Expected stale USER-history assertion not found; refusing unexpected patch.");
  source=source.replace(oldText,newText);
  fs.writeFileSync(target,source,"utf8");
  console.log("Updated Occurrence history regression for execution-scoped USER visibility.");
}

for(const artifact of fs.readdirSync(".")){
 if(/^APPLY-vnext-occurrence-history-visibility-test-fix-01\.(?:zip|mjs)$/i.test(artifact)){
  fs.unlinkSync(artifact);console.log(`Removed temporary artifact: ${artifact}`);
 }
}

execSync("npm run typecheck",{stdio:"inherit"});
execSync("npm run lint",{stdio:"inherit"});
execSync("git --no-pager diff --check",{stdio:"inherit"});
console.log("Occurrence history visibility test fix installed; typecheck, lint, and diff check passed.");
console.log("Migration 0013 is already applied. Do NOT reapply it.");
