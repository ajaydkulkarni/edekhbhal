import fs from "node:fs";
import { execSync } from "node:child_process";

const branch = execSync("git branch --show-current", { encoding: "utf8" }).trim();
if (branch !== "vNext") throw new Error(`Expected vNext branch, got ${branch}`);

// next-env.d.ts is Next-generated and should not be part of this functional commit.
try {
  execSync("git restore --source=HEAD -- next-env.d.ts", { stdio: "inherit" });
  console.log("Restored generated next-env.d.ts.");
} catch {
  console.log("next-env.d.ts restore skipped.");
}

// Remove temporary APPLY artifacts. If Git tracks them, the deletions are intentional
// and will be included in the product-source commit.
let removed = 0;
for (const name of fs.readdirSync(".")) {
  if (/^APPLY-vnext-.*\.(?:mjs|zip)$/i.test(name)) {
    fs.unlinkSync(name);
    removed += 1;
    console.log(`Removed temporary artifact: ${name}`);
  }
}
console.log(`Removed ${removed} temporary APPLY artifact(s).`);

execSync("git --no-pager diff --check", { stdio: "inherit" });

console.log("\n===== COMMIT CANDIDATE STATUS =====");
execSync("git status --short", { stdio: "inherit" });

console.log("\n===== COMMIT CANDIDATE DIFF STAT =====");
execSync("git --no-pager diff --stat", { stdio: "inherit" });

console.log("\nFunctional Schedule + command-boundary working tree cleanup complete.");
console.log("No application or database behavior was changed by this cleanup.");
