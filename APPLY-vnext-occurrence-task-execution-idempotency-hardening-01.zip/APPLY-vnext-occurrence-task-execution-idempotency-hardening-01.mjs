import fs from "node:fs";
import path from "node:path";
import {execSync} from "node:child_process";

const branch=execSync("git branch --show-current",{encoding:"utf8"}).trim();
if(branch!=="vNext")throw new Error(`Expected vNext branch, got ${branch}`);

const baseline="5f05615863f31200957475616f4541c19903ba88";
const head=execSync("git rev-parse HEAD",{encoding:"utf8"}).trim();
try{execSync(`git merge-base --is-ancestor ${baseline} ${head}`,{stdio:"ignore"});}
catch{throw new Error(`Current HEAD ${head} does not descend from Task Execution functional checkpoint ${baseline}`);}

const source=fs.readFileSync("drizzle/0014_occurrence_task_execution_completion.sql","utf8");
const start=source.indexOf("create or replace function app_private.complete_occurrence_task(");
const end=source.indexOf("revoke all on function app_private.audit_occurrence_task_event",start);
if(start<0||end<=start)throw new Error("Could not locate 0014 Task/partial completion function block.");
let sql=`-- Occurrence Task Execution Idempotency Hardening 01
-- Migration 0015: bind idempotency keys to the full meaningful request.
-- Migration 0014 is already applied and must not be replayed.

${source.slice(start,end)}`;

const replaceOnce=(text,oldText,newText,label)=>{
 if(text.includes(newText))return text;
 if(!text.includes(oldText))throw new Error(`0015 generation anchor missing: ${label}`);
 return text.replace(oldText,newText);
};

sql=replaceOnce(sql,
`  if clean_notes is not null and length(clean_notes)>4000 then
    raise exception 'Task notes cannot exceed 4000 characters';
  end if;
  if nullif(trim(p_idempotency_key),'') is null then`,
`  if clean_notes is not null and length(clean_notes)>4000 then
    raise exception 'Task notes cannot exceed 4000 characters';
  end if;
  if p_source_channel not in ('WEB','API','MOBILE') then
    raise exception 'Invalid source channel';
  end if;
  if nullif(trim(p_idempotency_key),'') is null then`,
"Task source validation");

sql=replaceOnce(sql,
`  if existing is not null then
    if (existing->>'occurrenceTaskId')::uuid<>p_occurrence_task_id then
      raise exception 'Idempotency key belongs to another Task completion';
    end if;
    return p_occurrence_task_id;
  end if;`,
`  if existing is not null then
    if (existing->>'occurrenceTaskId')::uuid<>p_occurrence_task_id
       or coalesce((existing->>'expectedVersion')::bigint,-1)<>p_expected_version
       or coalesce(existing->>'notes','')<>coalesce(clean_notes,'')
       or coalesce(existing->>'sourceChannel','')<>p_source_channel
    then
      raise exception 'Idempotency key belongs to another Task completion request';
    end if;
    return p_occurrence_task_id;
  end if;`,
"Task idempotency replay binding");

sql=replaceOnce(sql,
`    jsonb_build_object('occurrenceTaskId',task_row.id,'occurrenceId',occ.id)
  );`,
`    jsonb_build_object(
      'occurrenceTaskId',task_row.id,
      'occurrenceId',occ.id,
      'expectedVersion',p_expected_version,
      'notes',coalesce(clean_notes,''),
      'sourceChannel',p_source_channel
    )
  );`,
"Task idempotency result payload");

sql=replaceOnce(sql,
`  if length(clean_reason)>1000 then
    raise exception 'Partial completion reason cannot exceed 1000 characters';
  end if;
  if nullif(trim(p_idempotency_key),'') is null then`,
`  if length(clean_reason)>1000 then
    raise exception 'Partial completion reason cannot exceed 1000 characters';
  end if;
  if p_source_channel not in ('WEB','API','MOBILE') then
    raise exception 'Invalid source channel';
  end if;
  if nullif(trim(p_idempotency_key),'') is null then`,
"Partial source validation");

sql=replaceOnce(sql,
`  if existing is not null then
    if (existing->>'occurrenceId')::uuid<>p_occurrence_id then
      raise exception 'Idempotency key belongs to another partial completion';
    end if;
    return p_occurrence_id;
  end if;`,
`  if existing is not null then
    if (existing->>'occurrenceId')::uuid<>p_occurrence_id
       or coalesce((existing->>'expectedVersion')::bigint,-1)<>p_expected_version
       or coalesce(existing->>'reason','')<>clean_reason
       or coalesce(existing->>'sourceChannel','')<>p_source_channel
    then
      raise exception 'Idempotency key belongs to another partial completion request';
    end if;
    return p_occurrence_id;
  end if;`,
"Partial idempotency replay binding");

sql=replaceOnce(sql,
`    jsonb_build_object('occurrenceId',occ.id)
  );`,
`    jsonb_build_object(
      'occurrenceId',occ.id,
      'expectedVersion',p_expected_version,
      'reason',clean_reason,
      'sourceChannel',p_source_channel
    )
  );`,
"Partial idempotency result payload");

sql+=`
revoke all on function app_private.complete_occurrence_task(uuid,bigint,text,text,text)
  from public,anon,authenticated;
revoke all on function app_private.partially_complete_occurrence(uuid,bigint,text,text,text)
  from public,anon,authenticated;

grant execute on function app_private.complete_occurrence_task(uuid,bigint,text,text,text)
  to vnext_runtime;
grant execute on function app_private.partially_complete_occurrence(uuid,bigint,text,text,text)
  to vnext_runtime;
`;

fs.writeFileSync("drizzle/0015_occurrence_task_execution_idempotency_hardening.sql",sql);
console.log("Wrote drizzle/0015_occurrence_task_execution_idempotency_hardening.sql");

fs.writeFileSync("scripts/db-apply-occurrence-task-execution-hardening-15.mjs",`import fs from "node:fs";
import postgres from "postgres";

function loadEnv(path=".env.local"){
  if(!fs.existsSync(path))return;
  for(const raw of fs.readFileSync(path,"utf8").split(/\\\\r?\\\\n/)){
    const line=raw.trim();if(!line||line.startsWith("#"))continue;
    const i=line.indexOf("=");if(i<1)continue;
    const key=line.slice(0,i).trim();let value=line.slice(i+1).trim();
    if((value.startsWith('"')&&value.endsWith('"'))||(value.startsWith("'")&&value.endsWith("'")))value=value.slice(1,-1);
    if(!(key in process.env))process.env[key]=value;
  }
}
loadEnv();
const url=process.env.MIGRATION_DATABASE_URL;
if(!url)throw new Error("MIGRATION_DATABASE_URL is required.");
const db=postgres(url,{max:1,prepare:false,ssl:"require"});
try{
  await db.unsafe(fs.readFileSync("drizzle/0015_occurrence_task_execution_idempotency_hardening.sql","utf8"));
  const defs=await db\\\`
    select p.proname,pg_get_functiondef(p.oid) def
    from pg_proc p join pg_namespace n on n.oid=p.pronamespace
    where n.nspname='app_private'
      and p.proname in ('complete_occurrence_task','partially_complete_occurrence')
  \\\`;
  const combined=defs.map(x=>x.def).join("\\\\n");
  for(const required of["expectedVersion","sourceChannel","another Task completion request","another partial completion request"]){
    if(!combined.includes(required))throw new Error(\\\`0015 verification missing \\\${required}\\\`);
  }
  const priv=(await db\\\`
    select
      has_function_privilege('vnext_runtime','app_private.complete_occurrence_task(uuid,bigint,text,text,text)','EXECUTE') complete_exec,
      has_function_privilege('vnext_runtime','app_private.partially_complete_occurrence(uuid,bigint,text,text,text)','EXECUTE') partial_exec,
      has_table_privilege('vnext_runtime','public.schedule_occurrence_task','UPDATE') task_update,
      has_table_privilege('vnext_runtime','public.schedule_occurrence','UPDATE') occurrence_update
  \\\`)[0];
  if(!priv.complete_exec||!priv.partial_exec)throw new Error("0015 command grants are incomplete.");
  if(priv.task_update||priv.occurrence_update)throw new Error("0015 must not grant direct runtime Occurrence DML.");
  console.log("Occurrence Task Execution Idempotency Hardening 01 applied and verified.");
}finally{await db.end({timeout:5});}
`);
console.log("Wrote scripts/db-apply-occurrence-task-execution-hardening-15.mjs");

fs.writeFileSync("tests/module/occurrence-task-execution-idempotency-hardening-contract.test.ts",`import fs from "node:fs";
import {describe,expect,it} from "vitest";
const sql=fs.readFileSync("drizzle/0015_occurrence_task_execution_idempotency_hardening.sql","utf8");
describe("Occurrence Task Execution idempotency hardening contract",()=>{
 it("binds Task-completion replay to id, version, normalized notes and source",()=>{
  expect(sql).toContain("'expectedVersion',p_expected_version");
  expect(sql).toContain("'notes',coalesce(clean_notes,'')");
  expect(sql).toContain("'sourceChannel',p_source_channel");
  expect(sql).toContain("another Task completion request");
 });
 it("binds partial-completion replay to id, version, reason and source",()=>{
  expect(sql).toContain("'reason',clean_reason");
  expect(sql).toContain("another partial completion request");
 });
 it("retains fixed SECURITY DEFINER search paths and narrow grants",()=>{
  expect(sql.match(/security definer\\\\s+set search_path = pg_catalog, public/gi)?.length).toBe(2);
  expect(sql).toMatch(/grant execute on function app_private\\\\.complete_occurrence_task[\\\\s\\\\S]*vnext_runtime/i);
  expect(sql).toMatch(/grant execute on function app_private\\\\.partially_complete_occurrence[\\\\s\\\\S]*vnext_runtime/i);
 });
});
`);
console.log("Wrote tests/module/occurrence-task-execution-idempotency-hardening-contract.test.ts");

const patch=(file,oldText,newText)=>{
 let s=fs.readFileSync(file,"utf8");
 if(s.includes(newText)){console.log(`${file} patch already applied.`);return;}
 if(!s.includes(oldText))throw new Error(`Expected guarded anchor missing in ${file}; refusing unexpected patch.`);
 fs.writeFileSync(file,s.replace(oldText,newText));
 console.log(`Updated ${file}`);
};

patch("package.json",
`"db:task-execution:apply": "node scripts/db-apply-occurrence-task-execution-14.mjs"`,
`"db:task-execution:apply": "node scripts/db-apply-occurrence-task-execution-14.mjs",
    "db:task-execution:harden": "node scripts/db-apply-occurrence-task-execution-hardening-15.mjs"`);

patch("src/app/demo/page.tsx",
`No tenant context, wrong Site, stale QR, cross-tenant work, and conflicting concurrent claims fail closed.`,
`No tenant context, wrong Site, stale QR, cross-tenant work, conflicting concurrent claims, and mismatched idempotent replays fail closed.`);

patch("e2e/work-area-qr-demo.spec.ts",
` await expect(page.getByText(/wrong Site, stale QR, cross-tenant work/i)).toBeVisible();`,
` await expect(page.getByText(/wrong Site, stale QR, cross-tenant work/i)).toBeVisible();
 await expect(page.getByText(/mismatched idempotent replays fail closed/i)).toBeVisible();`);

for(const artifact of fs.readdirSync(".")){
 if(/^APPLY-vnext-occurrence-task-execution-idempotency-hardening-01\\.(?:zip|mjs)$/i.test(artifact)){
  fs.unlinkSync(artifact);console.log(`Removed temporary artifact: ${artifact}`);
 }
}

execSync("npm run typecheck",{stdio:"inherit"});
execSync("npm run lint",{stdio:"inherit"});
execSync("git --no-pager diff --check",{stdio:"inherit"});
console.log("Occurrence Task Execution Idempotency Hardening 01 installed; typecheck, lint, and diff check passed.");
console.log("Migration 0015 has NOT been applied yet. Apply it once with npm run db:task-execution:harden.");
console.log("Migration 0014 is already applied. Do NOT reapply 0014 or earlier migrations.");
