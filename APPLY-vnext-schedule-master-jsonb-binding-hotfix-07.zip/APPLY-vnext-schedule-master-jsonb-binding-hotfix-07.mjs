import fs from "node:fs";
import { execSync } from "node:child_process";

const branch = execSync("git branch --show-current", { encoding: "utf8" }).trim();
if (branch !== "vNext") throw new Error(`Expected vNext branch, got ${branch}`);

const actionsFile = "src/lib/schedules/actions.ts";
const testFile = "tests/integration/schedule-master-foundation.test.ts";
for (const file of [actionsFile, testFile]) {
  if (!fs.existsSync(file)) throw new Error(`${file} is missing.`);
}

// ---- Application JSONB bindings: use postgres.js json() helper so arrays/objects
// arrive as JSON values instead of a JSON string value.
let actions = fs.readFileSync(actionsFile, "utf8");

const recurrenceOld =
  '${i.recurrence.recurrenceConfig?JSON.stringify(i.recurrence.recurrenceConfig):null}::jsonb';
const recurrenceNew =
  '${i.recurrence.recurrenceConfig?tx.json(i.recurrence.recurrenceConfig):null}';

const tasksOld = '${JSON.stringify(i.tasks)}::jsonb';
const tasksNew = '${tx.json(i.tasks)}';

let recurrenceFixes = 0;
let taskFixes = 0;

while (actions.includes(recurrenceOld)) {
  actions = actions.replace(recurrenceOld, recurrenceNew);
  recurrenceFixes += 1;
}
while (actions.includes(tasksOld)) {
  actions = actions.replace(tasksOld, tasksNew);
  taskFixes += 1;
}

if (recurrenceFixes === 0 && !actions.includes(recurrenceNew)) {
  throw new Error("Could not find Schedule recurrence JSONB binding anchor.");
}
if (taskFixes === 0 && !actions.includes(tasksNew)) {
  throw new Error("Could not find Schedule Task JSONB binding anchor.");
}

fs.writeFileSync(actionsFile, actions, "utf8");
console.log(`Application JSONB bindings repaired: recurrence=${recurrenceFixes}, tasks=${taskFixes}.`);

// ---- Integration payload: return an actual JS array and bind through tx.json().
let test = fs.readFileSync(testFile, "utf8");

const helperOld = `const taskPayload=()=>JSON.stringify([
 {taskId:ids.taskA,sequence:1,plannedDurationMinutes:20,evidenceRule:"PHOTO",randomEveryN:null,randomEvidenceType:null},
 {taskId:ids.taskB,sequence:2,plannedDurationMinutes:15,evidenceRule:"RANDOM",randomEveryN:3,randomEvidenceType:"EITHER"}
]);`;

const helperNew = `const taskPayload=()=>[
 {taskId:ids.taskA,sequence:1,plannedDurationMinutes:20,evidenceRule:"PHOTO",randomEveryN:null,randomEvidenceType:null},
 {taskId:ids.taskB,sequence:2,plannedDurationMinutes:15,evidenceRule:"RANDOM",randomEveryN:3,randomEvidenceType:"EITHER"}
];`;

if (test.includes(helperOld)) {
  test = test.replace(helperOld, helperNew);
} else if (!test.includes(helperNew)) {
  throw new Error("Could not find taskPayload helper anchor.");
}

let payloadFixes = 0;
while (test.includes('${taskPayload()}::jsonb')) {
  test = test.replace('${taskPayload()}::jsonb', '${tx.json(taskPayload())}');
  payloadFixes += 1;
}

if (payloadFixes === 0 && !test.includes('${tx.json(taskPayload())}')) {
  throw new Error("Could not find Schedule integration JSONB payload anchors.");
}

fs.writeFileSync(testFile, test, "utf8");
console.log(`Integration JSONB Task payload bindings repaired: ${payloadFixes}.`);

execSync(
  "npx eslint src/lib/schedules/actions.ts tests/integration/schedule-master-foundation.test.ts",
  { stdio: "inherit" }
);
execSync("npm run typecheck", { stdio: "inherit" });
execSync("git --no-pager diff --check", { stdio: "inherit" });

console.log("Schedule JSONB binding hotfix passed ESLint, full typecheck, and diff check.");
console.log("Next: rerun the focused Schedule tests. Do NOT reapply migration 0008.");
