import fs from "node:fs";
import {execSync} from "node:child_process";

const branch=execSync("git branch --show-current",{encoding:"utf8"}).trim();
if(branch!=="vNext")throw new Error(`Expected vNext branch, got ${branch}`);

const baseline="5f05615863f31200957475616f4541c19903ba88";
const head=execSync("git rev-parse HEAD",{encoding:"utf8"}).trim();
try{execSync(`git merge-base --is-ancestor ${baseline} ${head}`,{stdio:"ignore"});}
catch{throw new Error(`Current HEAD ${head} does not descend from Task Execution functional checkpoint ${baseline}`);}

const target="tests/module/occurrence-task-execution-idempotency-hardening-contract.test.ts";
if(!fs.existsSync(target))throw new Error("Expected 0015 hardening contract test is missing.");

const [oldText,newText]=Buffer.from("ICBleHBlY3Qoc3FsLm1hdGNoKC9zZWN1cml0eSBkZWZpbmVyXFxzK3NldCBzZWFyY2hfcGF0aCA9IHBnX2NhdGFsb2csIHB1YmxpYy9naSk/Lmxlbmd0aCkudG9CZSgyKTsKICBleHBlY3Qoc3FsKS50b01hdGNoKC9ncmFudCBleGVjdXRlIG9uIGZ1bmN0aW9uIGFwcF9wcml2YXRlXFwuY29tcGxldGVfb2NjdXJyZW5jZV90YXNrW1xcc1xcU10qdm5leHRfcnVudGltZS9pKTsKICBleHBlY3Qoc3FsKS50b01hdGNoKC9ncmFudCBleGVjdXRlIG9uIGZ1bmN0aW9uIGFwcF9wcml2YXRlXFwucGFydGlhbGx5X2NvbXBsZXRlX29jY3VycmVuY2VbXFxzXFxTXSp2bmV4dF9ydW50aW1lL2kpOwotLS1QQUlSLS0tCiAgZXhwZWN0KHNxbC5tYXRjaCgvc2VjdXJpdHkgZGVmaW5lclxzK3NldCBzZWFyY2hfcGF0aCA9IHBnX2NhdGFsb2csIHB1YmxpYy9naSk/Lmxlbmd0aCkudG9CZSgyKTsKICBleHBlY3Qoc3FsKS50b01hdGNoKC9ncmFudCBleGVjdXRlIG9uIGZ1bmN0aW9uIGFwcF9wcml2YXRlXC5jb21wbGV0ZV9vY2N1cnJlbmNlX3Rhc2tbXHNcU10qdm5leHRfcnVudGltZS9pKTsKICBleHBlY3Qoc3FsKS50b01hdGNoKC9ncmFudCBleGVjdXRlIG9uIGZ1bmN0aW9uIGFwcF9wcml2YXRlXC5wYXJ0aWFsbHlfY29tcGxldGVfb2NjdXJyZW5jZVtcc1xTXSp2bmV4dF9ydW50aW1lL2kpOw==","base64").toString("utf8").split("\n---PAIR---\n");
let source=fs.readFileSync(target,"utf8");

if(source.includes(newText)){
 console.log("0015 hardening contract regex fix is already applied.");
}else{
 if(!source.includes(oldText))throw new Error("Expected double-escaped regex block not found; refusing unexpected patch.");
 source=source.replace(oldText,newText);
 fs.writeFileSync(target,source,"utf8");
 console.log("Corrected double-escaped RegExp literals in the 0015 hardening contract test.");
}

for(const artifact of fs.readdirSync(".")){
 if(/^APPLY-vnext-occurrence-task-execution-hardening-contract-regex-fix-01\.(?:zip|mjs)$/i.test(artifact)){
  fs.unlinkSync(artifact);console.log(`Removed temporary artifact: ${artifact}`);
 }
}

execSync("npm run typecheck",{stdio:"inherit"});
execSync("npm run lint",{stdio:"inherit"});
execSync("git --no-pager diff --check",{stdio:"inherit"});
console.log("0015 hardening contract regex fix installed; typecheck, lint, and diff check passed.");
console.log("Migration 0015 is already applied. Do NOT reapply 0015 or any earlier migration.");
